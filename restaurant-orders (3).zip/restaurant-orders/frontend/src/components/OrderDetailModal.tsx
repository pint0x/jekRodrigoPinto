/**
 * OrderDetailModal: Expanded view of an order showing every dish
 * with its ingredients list. As required by the spec, clicking
 * an order card should show ingredient-level detail.
 *
 * Also allows moving the order to the next/previous status
 * via buttons, providing an alternative to drag-and-drop.
 */
import type { Order, OrderStatus } from '../types';
import { ORDER_STATUSES } from '../types';

interface Props {
  order: Order;
  onClose: () => void;
  onStatusChange: (orderId: number, newStatus: OrderStatus) => void;
}

export default function OrderDetailModal({
  order,
  onClose,
  onStatusChange,
}: Props) {
  const currentIndex = ORDER_STATUSES.findIndex(
    (s) => s.key === order.status
  );
  const prevStatus = currentIndex > 0 ? ORDER_STATUSES[currentIndex - 1] : null;
  const nextStatus =
    currentIndex < ORDER_STATUSES.length - 1
      ? ORDER_STATUSES[currentIndex + 1]
      : null;

  const time = new Date(order.created_at).toLocaleTimeString('pt-PT', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const date = new Date(order.created_at).toLocaleDateString('pt-PT');

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>
          ✕
        </button>

        <div className="modal-header">
          <h2>
            Pedido #{order.id} — Mesa {order.table_number}
          </h2>
          <span className={`status-badge status-${order.status}`}>
            {order.status_display}
          </span>
        </div>

        <p className="modal-time">
          Recebido em {date} às {time}
        </p>

        {order.notes && (
          <div className="modal-notes">
            <strong>Notas:</strong> {order.notes}
          </div>
        )}

        <div className="modal-items">
          <h3>Pratos</h3>
          {order.lines.map((line) => (
            <div key={line.id} className="modal-dish">
              <div className="modal-dish-header">
                <span className="modal-dish-name">
                  {line.quantity}× {line.menu_item.name}
                </span>
                <span className="modal-dish-category">
                  {line.menu_item.category}
                </span>
              </div>
              <p className="modal-dish-description">
                {line.menu_item.description}
              </p>
              {/* Ingredients list — the key detail the kitchen needs */}
              <div className="modal-dish-ingredients">
                <strong>Ingredientes:</strong>
                <ul>
                  {line.menu_item.ingredients_list.map((ing, i) => (
                    <li key={i}>{ing}</li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Status transition buttons — alternative to drag-and-drop */}
        <div className="modal-actions">
          {prevStatus && (
            <button
              className="status-btn status-btn-back"
              onClick={() => onStatusChange(order.id, prevStatus.key)}
            >
              ← {prevStatus.label}
            </button>
          )}
          {nextStatus && (
            <button
              className="status-btn status-btn-next"
              onClick={() => onStatusChange(order.id, nextStatus.key)}
            >
              {nextStatus.label} →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
