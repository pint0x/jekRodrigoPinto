/**
 * KanbanColumn: A single column in the kitchen Kanban board.
 * Acts as a droppable zone for @dnd-kit. Shows a header with
 * column name, order count, and contains OrderCard components.
 */
import { useDroppable } from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import type { Order, OrderStatus } from '../types';
import OrderCard from './OrderCard';

interface Props {
  status: OrderStatus;
  label: string;
  orders: Order[];
  onCardClick: (order: Order) => void;
}

// Visual indicators per column status
const COLUMN_COLORS: Record<OrderStatus, string> = {
  order_preview: '#3b82f6',    // blue — new
  preparing: '#f59e0b',        // amber — active
  cooling_down: '#8b5cf6',     // purple — resting
  ready_to_serve: '#10b981',   // green — ready
  concluded: '#6b7280',        // gray — done
};

export default function KanbanColumn({
  status,
  label,
  orders,
  onCardClick,
}: Props) {
  const { setNodeRef, isOver } = useDroppable({ id: status });

  return (
    <div
      ref={setNodeRef}
      className={`kanban-column ${isOver ? 'kanban-column-over' : ''}`}
    >
      <div
        className="kanban-column-header"
        style={{ borderBottomColor: COLUMN_COLORS[status] }}
      >
        <span className="kanban-column-title">{label}</span>
        <span
          className="kanban-column-count"
          style={{ backgroundColor: COLUMN_COLORS[status] }}
        >
          {orders.length}
        </span>
      </div>

      <SortableContext
        items={orders.map((o) => `order-${o.id}`)}
        strategy={verticalListSortingStrategy}
      >
        <div className="kanban-column-body">
          {orders.length === 0 ? (
            <p className="kanban-column-empty">Sem pedidos</p>
          ) : (
            orders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                onClick={onCardClick}
              />
            ))
          )}
        </div>
      </SortableContext>
    </div>
  );
}
