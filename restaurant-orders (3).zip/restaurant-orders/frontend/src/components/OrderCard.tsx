/**
 * OrderCard: Compact representation of an order on the Kanban board.
 * Shows table number, item count, and time received.
 * Clicking opens the detail modal.
 *
 * Uses @dnd-kit/sortable for drag-and-drop Kanban support.
 */
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type { Order } from '../types';

interface Props {
  order: Order;
  onClick: (order: Order) => void;
}

export default function OrderCard({ order, onClick }: Props) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: `order-${order.id}`, data: { order } });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  // Format time as HH:MM
  const time = new Date(order.created_at).toLocaleTimeString('pt-PT', {
    hour: '2-digit',
    minute: '2-digit',
  });

  // Calculate time elapsed since order
  const minutesAgo = Math.floor(
    (Date.now() - new Date(order.created_at).getTime()) / 60000
  );
  const timeAgo =
    minutesAgo < 1
      ? 'agora mesmo'
      : minutesAgo < 60
        ? `há ${minutesAgo}min`
        : `há ${Math.floor(minutesAgo / 60)}h${minutesAgo % 60}min`;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`order-card ${isDragging ? 'order-card-dragging' : ''}`}
      onClick={() => onClick(order)}
      {...attributes}
      {...listeners}
    >
      <div className="order-card-header">
        <span className="order-card-table">Mesa {order.table_number}</span>
        <span className="order-card-id">#{order.id}</span>
      </div>

      <ul className="order-card-items">
        {order.lines.map((line) => (
          <li key={line.id}>
            <span className="order-card-qty">{line.quantity}×</span>{' '}
            {line.menu_item.name}
          </li>
        ))}
      </ul>

      {order.notes && (
        <p className="order-card-notes">📝 {order.notes}</p>
      )}

      <div className="order-card-footer">
        <span className="order-card-time" title={time}>
          🕐 {timeAgo}
        </span>
        <span className="order-card-items-count">
          {order.lines.reduce((sum, l) => sum + l.quantity, 0)} pratos
        </span>
      </div>
    </div>
  );
}
