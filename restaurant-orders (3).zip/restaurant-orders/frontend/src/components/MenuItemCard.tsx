/**
 * MenuItemCard: Displays a single dish with name, description, price,
 * and a quantity selector with add-to-cart button.
 *
 * Controlled quantity state resets after adding to keep the UX clean.
 */
import { useState } from 'react';
import type { MenuItem } from '../types';

interface Props {
  item: MenuItem;
  onAdd: (item: MenuItem, quantity: number) => void;
}

export default function MenuItemCard({ item, onAdd }: Props) {
  const [quantity, setQuantity] = useState(1);

  const handleAdd = () => {
    onAdd(item, quantity);
    setQuantity(1); // Reset after adding
  };

  return (
    <div className="menu-item-card">
      <div className="menu-item-info">
        <h3 className="menu-item-name">{item.name}</h3>
        <p className="menu-item-description">{item.description}</p>
        <span className="menu-item-price">€{Number(item.price).toFixed(2)}</span>
      </div>
      <div className="menu-item-actions">
        <div className="quantity-selector">
          <button
            className="qty-btn"
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            aria-label="Diminuir quantidade"
          >
            −
          </button>
          <span className="qty-value">{quantity}</span>
          <button
            className="qty-btn"
            onClick={() => setQuantity(quantity + 1)}
            aria-label="Aumentar quantidade"
          >
            +
          </button>
        </div>
        <button className="add-btn" onClick={handleAdd}>
          Adicionar
        </button>
      </div>
    </div>
  );
}
