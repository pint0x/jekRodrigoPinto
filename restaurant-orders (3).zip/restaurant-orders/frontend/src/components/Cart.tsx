/**
 * Cart: Displays the current order items, allows quantity adjustments,
 * item removal, and order submission.
 *
 * Receives cart state and handlers from the parent page to keep state
 * management in one place (lifted state pattern).
 */
import type { CartItem } from '../types';

interface Props {
  items: CartItem[];
  tableNumber: number;
  notes: string;
  onUpdateQuantity: (menuItemId: number, delta: number) => void;
  onRemove: (menuItemId: number) => void;
  onSubmit: () => void;
  onClear: () => void;
  isSubmitting: boolean;
}

export default function Cart({
  items,
  tableNumber,
  notes,
  onUpdateQuantity,
  onRemove,
  onSubmit,
  onClear,
  isSubmitting,
}: Props) {
  const total = items.reduce(
    (sum, ci) => sum + Number(ci.menuItem.price) * ci.quantity,
    0
  );

  if (items.length === 0) {
    return (
      <div className="cart cart-empty">
        <h2>O seu pedido</h2>
        <p className="cart-empty-text">
          Ainda não adicionou nenhum prato. Explore o menu e adicione os pratos desejados.
        </p>
      </div>
    );
  }

  return (
    <div className="cart">
      <div className="cart-header">
        <h2>O seu pedido</h2>
        <span className="cart-table-badge">Mesa {tableNumber}</span>
      </div>

      <div className="cart-items">
        {items.map((ci) => (
          <div key={ci.menuItem.id} className="cart-item">
            <div className="cart-item-info">
              <span className="cart-item-name">{ci.menuItem.name}</span>
              <span className="cart-item-price">
                €{(Number(ci.menuItem.price) * ci.quantity).toFixed(2)}
              </span>
            </div>
            <div className="cart-item-controls">
              <button
                className="qty-btn qty-btn-sm"
                onClick={() => onUpdateQuantity(ci.menuItem.id, -1)}
              >
                −
              </button>
              <span className="qty-value">{ci.quantity}</span>
              <button
                className="qty-btn qty-btn-sm"
                onClick={() => onUpdateQuantity(ci.menuItem.id, 1)}
              >
                +
              </button>
              <button
                className="remove-btn"
                onClick={() => onRemove(ci.menuItem.id)}
                aria-label={`Remover ${ci.menuItem.name}`}
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>

      {notes && (
        <div className="cart-notes">
          <small>Notas: {notes}</small>
        </div>
      )}

      <div className="cart-footer">
        <div className="cart-total">
          <span>Total</span>
          <span className="cart-total-value">€{total.toFixed(2)}</span>
        </div>
        <button
          className="submit-btn"
          onClick={onSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? 'A enviar...' : 'Confirmar Pedido'}
        </button>
        <button className="clear-btn" onClick={onClear}>
          Limpar Pedido
        </button>
      </div>
    </div>
  );
}
