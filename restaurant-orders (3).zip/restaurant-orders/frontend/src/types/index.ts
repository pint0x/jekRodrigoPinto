/**
 * Type definitions for the Restaurant Order Management System.
 * These mirror the Django model/serializer structure to ensure type safety
 * across the full stack.
 */

// ── Menu ──

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  category: MenuCategory;
  ingredients: string;
  ingredients_list: string[];
  // Django DecimalField is serialized as string by DRF (e.g. "8.50")
  // Use Number() to convert before arithmetic or formatting.
  price: string | number;
  is_available: boolean;
}

export type MenuCategory = 'entradas' | 'sopas' | 'carne' | 'peixe' | 'sobremesa';

// Display labels for categories (Portuguese)
export const CATEGORY_LABELS: Record<MenuCategory, string> = {
  entradas: 'Entradas',
  sopas: 'Sopas',
  carne: 'Carne',
  peixe: 'Peixe',
  sobremesa: 'Sobremesa',
};

// Category icons for visual distinction
export const CATEGORY_ICONS: Record<MenuCategory, string> = {
  entradas: '🥗',
  sopas: '🍲',
  carne: '🥩',
  peixe: '🐟',
  sobremesa: '🍮',
};

// ── Orders ──

export type OrderStatus =
  | 'order_preview'
  | 'preparing'
  | 'cooling_down'
  | 'ready_to_serve'
  | 'concluded';

// Kanban column definitions matching the spec exactly
export const ORDER_STATUSES: { key: OrderStatus; label: string }[] = [
  { key: 'order_preview', label: 'Order Preview' },
  { key: 'preparing', label: 'Preparing' },
  { key: 'cooling_down', label: 'Cooling Down' },
  { key: 'ready_to_serve', label: 'Ready to Serve' },
  { key: 'concluded', label: 'Concluded' },
];

export interface OrderLine {
  id: number;
  menu_item: MenuItem;
  quantity: number;
}

export interface Order {
  id: number;
  table_number: number;
  status: OrderStatus;
  status_display: string;
  created_at: string;
  updated_at: string;
  notes: string;
  lines: OrderLine[];
}

// ── Cart (client-side only) ──

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
}
