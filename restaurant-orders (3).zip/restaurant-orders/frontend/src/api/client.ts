/**
 * API client for communicating with the Django backend.
 *
 * Design: simple fetch wrapper instead of Axios — fewer dependencies,
 * native browser API, sufficient for this scope. Axios would add value
 * with interceptors/retry logic in a larger app, but here it's overkill.
 */
import type { MenuItem, Order, OrderStatus } from '../types';

// Use relative path so requests go through Vite's dev proxy (vite.config.ts).
// This avoids CORS issues entirely — the browser talks to localhost:5173,
// and Vite forwards /api/* to localhost:8000 behind the scenes.
const API_BASE = import.meta.env.VITE_API_URL || '/api';

/**
 * Generic fetch helper with error handling.
 */
async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(
      errorData.error || errorData.errors
        ? JSON.stringify(errorData.errors || errorData.error)
        : `Request failed: ${response.status}`
    );
  }

  return response.json();
}

// ── Menu endpoints ──

export function fetchMenu(category?: string): Promise<MenuItem[]> {
  const params = category ? `?category=${category}` : '';
  return request<MenuItem[]>(`/menu/${params}`);
}

export function fetchMenuItem(id: number): Promise<MenuItem> {
  return request<MenuItem>(`/menu/${id}/`);
}

// ── Order endpoints ──

export interface CreateOrderPayload {
  table_number: number;
  notes?: string;
  lines: { menu_item_id: number; quantity: number }[];
}

export function createOrder(payload: CreateOrderPayload): Promise<Order> {
  return request<Order>('/orders/', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function fetchOrders(status?: OrderStatus): Promise<Order[]> {
  const params = status ? `?status=${status}` : '';
  return request<Order[]>(`/orders/list/${params}`);
}

export function fetchOrder(id: number): Promise<Order> {
  return request<Order>(`/orders/${id}/`);
}

export function updateOrderStatus(
  id: number,
  status: OrderStatus
): Promise<Order> {
  return request<Order>(`/orders/${id}/status/`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

// ── SSE: real-time updates ──

/**
 * Connects to the SSE stream and calls onRefresh whenever the server
 * signals new data. Returns a cleanup function to close the connection.
 *
 * Why SSE over WebSockets: the data flow is unidirectional (server → kitchen).
 * SSE is simpler, uses standard HTTP, auto-reconnects, and requires no
 * additional infrastructure.
 */
export function connectSSE(onRefresh: () => void): () => void {
  const eventSource = new EventSource(`${API_BASE}/orders/stream/`);

  eventSource.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === 'refresh') {
        onRefresh();
      }
    } catch {
      // Ignore malformed messages
    }
  };

  eventSource.onerror = () => {
    // EventSource auto-reconnects; no manual handling needed.
    console.warn('SSE connection lost, will auto-reconnect...');
  };

  // Return cleanup function
  return () => eventSource.close();
}
