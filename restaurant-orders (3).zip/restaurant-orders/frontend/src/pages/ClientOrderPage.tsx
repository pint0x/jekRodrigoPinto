/**
 * ClientOrderPage: The customer-facing interface.
 *
 * Flow: Select table → Browse menu by category → Add items → Review cart → Submit.
 * After submission, cart resets and a success message is shown.
 *
 * State management: useState is sufficient here — the state is local, not shared,
 * and the data flow is simple. Redux/Zustand would be over-engineering for this scope.
 */
import { useState, useEffect, useCallback } from 'react';
import type { MenuItem, MenuCategory, CartItem } from '../types';
import { CATEGORY_LABELS, CATEGORY_ICONS } from '../types';
import { fetchMenu, createOrder } from '../api/client';
import MenuItemCard from '../components/MenuItemCard';
import Cart from '../components/Cart';

const CATEGORIES: MenuCategory[] = [
  'entradas',
  'sopas',
  'carne',
  'peixe',
  'sobremesa',
];

export default function ClientOrderPage() {
  // ── State ──
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<MenuCategory>('entradas');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [tableNumber, setTableNumber] = useState<number>(0);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // ── Fetch menu on mount ──
  const loadMenu = useCallback(() => {
    setLoading(true);
    setError('');
    fetchMenu()
      .then((items) => {
        setMenuItems(items);
        console.log(`Menu loaded: ${items.length} items`);
      })
      .catch((err) => {
        console.error('Failed to load menu:', err);
        setError(
          'Erro ao carregar o menu. Verifique que o backend está a correr (python manage.py runserver) e tente novamente.'
        );
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    loadMenu();
  }, [loadMenu]);

  // ── Cart operations ──
  const addToCart = useCallback((item: MenuItem, quantity: number) => {
    setCart((prev) => {
      const existing = prev.find((ci) => ci.menuItem.id === item.id);
      if (existing) {
        // Increment quantity if already in cart
        return prev.map((ci) =>
          ci.menuItem.id === item.id
            ? { ...ci, quantity: ci.quantity + quantity }
            : ci
        );
      }
      return [...prev, { menuItem: item, quantity }];
    });
    setSuccessMessage('');
  }, []);

  const updateQuantity = useCallback((menuItemId: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((ci) =>
          ci.menuItem.id === menuItemId
            ? { ...ci, quantity: Math.max(0, ci.quantity + delta) }
            : ci
        )
        .filter((ci) => ci.quantity > 0)
    );
  }, []);

  const removeFromCart = useCallback((menuItemId: number) => {
    setCart((prev) => prev.filter((ci) => ci.menuItem.id !== menuItemId));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setNotes('');
  }, []);

  // ── Submit order ──
  const handleSubmit = async () => {
    if (tableNumber < 1) {
      setError('Por favor selecione o número da mesa.');
      return;
    }
    if (cart.length === 0) {
      setError('Adicione pelo menos um prato ao pedido.');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const order = await createOrder({
        table_number: tableNumber,
        notes,
        lines: cart.map((ci) => ({
          menu_item_id: ci.menuItem.id,
          quantity: ci.quantity,
        })),
      });

      // Success — reset for next order
      setCart([]);
      setNotes('');
      setSuccessMessage(
        `Pedido #${order.id} enviado com sucesso! A cozinha já recebeu o seu pedido.`
      );

      // Auto-dismiss success message after 5 seconds
      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Erro ao submeter o pedido. Tente novamente.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // ── Filter items by active category ──
  const filteredItems = menuItems.filter(
    (item) => item.category === activeCategory
  );

  // ── Table selection screen ──
  if (tableNumber < 1) {
    return (
      <div className="table-select-page">
        <div className="table-select-container">
          <h1 className="app-title">🍽️ Restaurante</h1>
          <p className="table-select-subtitle">
            Selecione o número da sua mesa para começar
          </p>
          <div className="table-grid">
            {Array.from({ length: 12 }, (_, i) => i + 1).map((num) => (
              <button
                key={num}
                className="table-btn"
                onClick={() => setTableNumber(num)}
              >
                {num}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="client-page">
      {/* Header */}
      <header className="client-header">
        <div className="client-header-left">
          <h1>🍽️ Menu</h1>
          <span className="header-table-badge">Mesa {tableNumber}</span>
        </div>
        <button
          className="change-table-btn"
          onClick={() => {
            setTableNumber(0);
            clearCart();
          }}
        >
          Trocar Mesa
        </button>
      </header>

      {/* Feedback messages */}
      {successMessage && (
        <div className="message message-success">{successMessage}</div>
      )}
      {error && (
        <div className="message message-error">
          {error}
          <button onClick={() => setError('')} className="message-dismiss">✕</button>
        </div>
      )}

      <div className="client-layout">
        {/* Main content — menu */}
        <main className="menu-section">
          {/* Category tabs */}
          <nav className="category-tabs">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                className={`category-tab ${
                  activeCategory === cat ? 'category-tab-active' : ''
                }`}
                onClick={() => setActiveCategory(cat)}
              >
                <span className="category-tab-icon">
                  {CATEGORY_ICONS[cat]}
                </span>
                <span>{CATEGORY_LABELS[cat]}</span>
              </button>
            ))}
          </nav>

          {/* Menu items grid */}
          {loading ? (
            <div className="loading-state">A carregar menu...</div>
          ) : error && menuItems.length === 0 ? (
            <div className="loading-state">
              <p style={{ color: '#dc2626', marginBottom: '12px' }}>{error}</p>
              <button className="add-btn" onClick={loadMenu}>
                ↻ Tentar novamente
              </button>
            </div>
          ) : (
            <div className="menu-grid">
              {filteredItems.map((item) => (
                <MenuItemCard
                  key={item.id}
                  item={item}
                  onAdd={addToCart}
                />
              ))}
            </div>
          )}

          {/* Notes field — beyond requirements, but useful */}
          <div className="notes-section">
            <label htmlFor="order-notes">
              Notas adicionais (alergias, preferências, etc.)
            </label>
            <textarea
              id="order-notes"
              className="notes-input"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Sem glúten, sem cebola..."
              rows={2}
            />
          </div>
        </main>

        {/* Sidebar — cart */}
        <aside className="cart-section">
          <Cart
            items={cart}
            tableNumber={tableNumber}
            notes={notes}
            onUpdateQuantity={updateQuantity}
            onRemove={removeFromCart}
            onSubmit={handleSubmit}
            onClear={clearCart}
            isSubmitting={isSubmitting}
          />
        </aside>
      </div>
    </div>
  );
}
