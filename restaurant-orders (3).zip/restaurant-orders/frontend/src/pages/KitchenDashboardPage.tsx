/**
 * KitchenDashboardPage: The kitchen-facing Kanban board.
 *
 * Features:
 * - 5-column Kanban board matching the order pipeline
 * - Drag-and-drop via @dnd-kit (bonus feature)
 * - Real-time updates via SSE (bonus feature)
 * - Manual refresh button as fallback
 * - Click-to-expand detail modal with ingredients
 *
 * @dnd-kit was chosen over react-beautiful-dnd because:
 * - react-beautiful-dnd is deprecated (no longer maintained by Atlassian)
 * - @dnd-kit is actively maintained, lighter, and more flexible
 * - Better accessibility support out of the box
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import {
  DndContext,
  DragOverlay,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragStartEvent,
  type DragEndEvent,
} from '@dnd-kit/core';
import type { Order, OrderStatus } from '../types';
import { ORDER_STATUSES } from '../types';
import { fetchOrders, updateOrderStatus, connectSSE } from '../api/client';
import KanbanColumn from '../components/KanbanColumn';
import OrderCard from '../components/OrderCard';
import OrderDetailModal from '../components/OrderDetailModal';

export default function KitchenDashboardPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [sseConnected, setSseConnected] = useState(false);

  // Track if component is mounted to avoid state updates after unmount
  const mountedRef = useRef(true);

  // ── Fetch all orders ──
  const loadOrders = useCallback(async () => {
    try {
      const data = await fetchOrders();
      if (mountedRef.current) {
        setOrders(data);
        setError('');
      }
    } catch {
      if (mountedRef.current) {
        setError('Erro ao carregar pedidos.');
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }, []);

  // ── Initial load + SSE connection ──
  useEffect(() => {
    mountedRef.current = true;
    loadOrders();

    // Connect SSE for real-time updates
    const disconnect = connectSSE(() => {
      if (mountedRef.current) {
        setSseConnected(true);
        loadOrders();
      }
    });

    setSseConnected(true);

    return () => {
      mountedRef.current = false;
      disconnect();
    };
  }, [loadOrders]);

  // ── Status change handler (used by both modal buttons and drag-and-drop) ──
  const handleStatusChange = useCallback(
    async (orderId: number, newStatus: OrderStatus) => {
      try {
        const updated = await updateOrderStatus(orderId, newStatus);
        setOrders((prev) =>
          prev.map((o) => (o.id === updated.id ? updated : o))
        );
        // Also update modal if open
        setSelectedOrder((prev) =>
          prev?.id === updated.id ? updated : prev
        );
      } catch {
        setError('Erro ao atualizar estado do pedido.');
      }
    },
    []
  );

  // ── Drag and drop setup ──
  // activationConstraint prevents accidental drags when clicking
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 8 },
    })
  );

  const handleDragStart = (event: DragStartEvent) => {
    const order = (event.active.data.current as { order: Order })?.order;
    if (order) setActiveOrder(order);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveOrder(null);
    const { active, over } = event;
    if (!over) return;

    const order = (active.data.current as { order: Order })?.order;
    if (!order) return;

    // The droppable ID is the status key (e.g., 'preparing')
    const newStatus = over.id as OrderStatus;

    // Only update if status actually changed
    if (order.status !== newStatus) {
      handleStatusChange(order.id, newStatus);
    }
  };

  // ── Group orders by status for column rendering ──
  const ordersByStatus: Record<OrderStatus, Order[]> = {
    order_preview: [],
    preparing: [],
    cooling_down: [],
    ready_to_serve: [],
    concluded: [],
  };

  orders.forEach((order) => {
    if (ordersByStatus[order.status]) {
      ordersByStatus[order.status].push(order);
    }
  });

  return (
    <div className="kitchen-page">
      {/* Header */}
      <header className="kitchen-header">
        <div className="kitchen-header-left">
          <h1>👨‍🍳 Cozinha</h1>
          <span
            className={`sse-indicator ${
              sseConnected ? 'sse-connected' : 'sse-disconnected'
            }`}
            title={
              sseConnected
                ? 'Atualizações em tempo real ativas'
                : 'Sem ligação em tempo real'
            }
          >
            {sseConnected ? '● Tempo real' : '○ Desligado'}
          </span>
        </div>
        <div className="kitchen-header-right">
          <span className="order-count">
            {orders.filter((o) => o.status !== 'concluded').length} pedidos ativos
          </span>
          <button className="refresh-btn" onClick={loadOrders}>
            ↻ Atualizar
          </button>
        </div>
      </header>

      {/* Error/loading states */}
      {error && (
        <div className="message message-error">
          {error}
          <button onClick={() => setError('')} className="message-dismiss">✕</button>
        </div>
      )}

      {loading ? (
        <div className="loading-state">A carregar pedidos...</div>
      ) : (
        /* Kanban board with drag-and-drop context */
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="kanban-board">
            {ORDER_STATUSES.map(({ key, label }) => (
              <KanbanColumn
                key={key}
                status={key}
                label={label}
                orders={ordersByStatus[key]}
                onCardClick={setSelectedOrder}
              />
            ))}
          </div>

          {/* Drag overlay — shows a ghost card while dragging */}
          <DragOverlay>
            {activeOrder ? (
              <OrderCard
                order={activeOrder}
                onClick={() => {}}
              />
            ) : null}
          </DragOverlay>
        </DndContext>
      )}

      {/* Detail modal */}
      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onStatusChange={(id, status) => {
            handleStatusChange(id, status);
          }}
        />
      )}
    </div>
  );
}
