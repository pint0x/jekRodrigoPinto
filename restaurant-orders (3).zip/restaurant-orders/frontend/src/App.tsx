/**
 * App: Root component with client-side routing.
 *
 * Routes:
 * - /         → Client order interface (the "table" view)
 * - /kitchen  → Kitchen dashboard (the Kanban board)
 *
 * React Router v6 is used for declarative routing. A simple nav bar
 * allows switching between views for demo purposes — in a real
 * deployment, these would be on separate devices/screens.
 */
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import ClientOrderPage from './pages/ClientOrderPage';
import KitchenDashboardPage from './pages/KitchenDashboardPage';

export default function App() {
  return (
    <BrowserRouter>
      {/* Navigation — for demo convenience. In production, client and
          kitchen would be on different tablets/screens. */}
      <nav className="main-nav">
        <NavLink to="/" end className={({ isActive }) => isActive ? 'nav-link nav-link-active' : 'nav-link'}>
          🍽️ Cliente
        </NavLink>
        <NavLink to="/kitchen" className={({ isActive }) => isActive ? 'nav-link nav-link-active' : 'nav-link'}>
          👨‍🍳 Cozinha
        </NavLink>
      </nav>

      <Routes>
        <Route path="/" element={<ClientOrderPage />} />
        <Route path="/kitchen" element={<KitchenDashboardPage />} />
      </Routes>
    </BrowserRouter>
  );
}
