# 🍽️ Sistema de Gestão de Pedidos para Restaurante

Aplicação web full-stack para gestão de pedidos num ambiente de restaurante, composta por uma **interface de pedidos para o cliente** e um **dashboard de cozinha** com quadro Kanban.

## Stack Tecnológico

| Camada | Tecnologia | Justificação |
|--------|-----------|--------------|
| **Backend** | Python / Django + Django REST Framework | Django é robusto, maduro e ideal para prototipar rapidamente um backend REST com modelos bem definidos. O ORM facilita a modelação de dados e as migrações. O DRF fornece serialização, validação e convenções REST prontas a usar. |
| **Frontend** | React (TypeScript) + Vite | React é o standard da indústria para SPAs interativas. TypeScript adiciona segurança de tipos que evita erros em runtime. Vite oferece build instantâneo (HMR) vs. o lento Webpack do CRA. |
| **Base de dados** | SQLite | Zero configuração, ficheiro único, ideal para um sistema pequeno e autocontido. Elimina a necessidade de instalar/configurar PostgreSQL para correr o projeto localmente. |
| **Tempo real** | Server-Sent Events (SSE) | O fluxo de dados é unidirecional (servidor → cozinha). SSE é mais simples que WebSockets, funciona sobre HTTP standard, tem auto-reconexão nativa, e não requer infraestrutura adicional (Channels, Redis, Daphne). |
| **Drag & Drop** | @dnd-kit | Biblioteca moderna e ativamente mantida (ao contrário do react-beautiful-dnd, descontinuado pela Atlassian). Leve, acessível, e com API flexível. |
| **Styling** | CSS puro com Custom Properties | Simplicidade máxima: zero dependência de build para estilos, fácil de ler e auditar. Custom Properties dão capacidade de temas. Para este scope, Tailwind ou SCSS adicionariam complexidade desnecessária. |

## Funcionalidades

### Interface do Cliente (`/`)
- Seleção de mesa (1-12)
- Menu dividido em 5 categorias: Entradas, Sopas, Carne, Peixe, Sobremesa
- Seleção de quantidade por prato
- Carrinho com revisão completa do pedido
- Campo de notas (alergias, preferências)
- Feedback visual após submissão + reset automático

### Dashboard de Cozinha (`/kitchen`)
- Quadro Kanban com 5 colunas (Order Preview → Concluded)
- **Drag-and-drop** para mover pedidos entre colunas (bónus)
- **Atualizações em tempo real via SSE** (bónus)
- Botão de refresh manual como fallback
- Modal de detalhe com ingredientes de cada prato
- Botões de avançar/recuar estado no modal
- Indicador de tempo desde a receção do pedido
- Indicador de estado da ligação SSE

## Como Correr o Projeto

### Pré-requisitos
- **Python** 3.10+ (testado com 3.12)
- **Node.js** 18+ (testado com 20)
- **npm** 9+

### 1. Backend (Django)

```bash
# Navegar para a pasta do backend
cd backend

# (Opcional) Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/macOS
# venv\Scripts\activate   # Windows

# Instalar dependências
pip install -r requirements.txt

# Aplicar migrações
python manage.py migrate

# Popular a base de dados com o menu
python manage.py seed

# Iniciar o servidor (porta 8000)
python manage.py runserver
```

O backend estará disponível em `http://localhost:8000/api/`.

### 2. Frontend (React)

```bash
# Numa nova janela de terminal, navegar para a pasta do frontend
cd frontend

# Instalar dependências
npm install

# Iniciar o servidor de desenvolvimento (porta 5173)
npm run dev
```

A aplicação estará disponível em `http://localhost:5173/`.

### Utilização

1. Abrir `http://localhost:5173/` — selecionar uma mesa e fazer um pedido
2. Abrir `http://localhost:5173/kitchen` — ver o pedido aparecer no dashboard
3. Arrastar o cartão do pedido entre colunas, ou clicar para ver detalhes e usar os botões

## Modelo de Dados

```
MenuItem (id, name, description, category, ingredients, price, is_available)
    |
    └──< OrderLine (id, order_id, menu_item_id, quantity)
              |
              └──> Order (id, table_number, status, created_at, updated_at, notes)
```

- **MenuItem**: pratos com categoria fixa (choices), ingredientes como texto separado por vírgulas
- **Order**: ligado a uma mesa, com estado que percorre o pipeline da cozinha
- **OrderLine**: tabela de junção normalizada entre Order e MenuItem

## API REST

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| `GET` | `/api/menu/` | Lista o menu (opcional: `?category=entradas`) |
| `GET` | `/api/menu/:id/` | Detalhe de um prato |
| `POST` | `/api/orders/` | Criar novo pedido |
| `GET` | `/api/orders/list/` | Listar pedidos (opcional: `?status=preparing`) |
| `GET` | `/api/orders/:id/` | Detalhe de um pedido |
| `PATCH` | `/api/orders/:id/status/` | Atualizar estado de um pedido |
| `GET` | `/api/orders/stream/` | Stream SSE para atualizações em tempo real |

## Estrutura do Projeto

```
restaurant-orders/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── restaurant/          # Django project settings
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   └── orders/              # Django app
│       ├── models.py        # MenuItem, Order, OrderLine
│       ├── serializers.py   # DRF serializers (read + write)
│       ├── views.py         # API views + SSE endpoint
│       ├── urls.py          # Route definitions
│       ├── admin.py         # Django admin config
│       └── management/commands/seed.py  # DB seeding
├── frontend/
│   ├── src/
│   │   ├── api/client.ts       # API client + SSE connection
│   │   ├── types/index.ts      # TypeScript type definitions
│   │   ├── components/         # Reusable UI components
│   │   │   ├── MenuItemCard.tsx
│   │   │   ├── Cart.tsx
│   │   │   ├── OrderCard.tsx
│   │   │   ├── OrderDetailModal.tsx
│   │   │   └── KanbanColumn.tsx
│   │   ├── pages/              # Page-level components
│   │   │   ├── ClientOrderPage.tsx
│   │   │   └── KitchenDashboardPage.tsx
│   │   ├── App.tsx             # Router
│   │   ├── main.tsx            # Entry point
│   │   └── index.css           # All styles
│   ├── index.html
│   ├── vite.config.ts
│   └── package.json
├── TECHNICAL_DECISIONS.md       # Decisões técnicas detalhadas
└── README.md
```

## O Que Melhoraria com Mais Tempo

- **Testes**: adicionar testes unitários ao backend (pytest-django) e ao frontend (Vitest + Testing Library)
- **Validação de transições**: impor uma ordem válida de estados (ex: não permitir saltar de "Order Preview" para "Concluded")
- **Paginação**: para o endpoint de listagem de pedidos, evitar carregar todos os pedidos de uma vez
- **Docker**: Dockerfile + docker-compose para setup com um único comando
- **Notificações sonoras**: alerta na cozinha quando chega um novo pedido
- **Filtros no dashboard**: filtrar pedidos por mesa ou intervalo de tempo
- **Gestão de menu**: interface admin para editar pratos sem usar o Django admin
- **PWA**: tornar a interface do cliente instalável num tablet

## Decisões Técnicas

Para uma explicação detalhada de todas as decisões arquiteturais, trade-offs e justificações, consultar o ficheiro [`TECHNICAL_DECISIONS.md`](./TECHNICAL_DECISIONS.md).
