"""
Data models for the Restaurant Order Management System.

Schema design rationale:
- MenuItem: stores dish info with category as a CharField with choices (simple, avoids
  a separate Category table for 5 fixed categories). Ingredients stored as a TextField
  (comma-separated) — adequate for display purposes without needing a full M2M relation.
- Order: linked to a table number, tracks status through the kitchen pipeline.
  Uses created_at for display ordering and timestamps.
- OrderLine: junction table between Order and MenuItem. Stores quantity per dish.
  This normalized design avoids data duplication and supports flexible queries.
"""
from django.db import models


class MenuItem(models.Model):
    """A dish on the restaurant menu."""

    # Fixed categories as per spec — CharField with choices is simpler than a FK table
    # for a small, static set of values that won't change at runtime.
    CATEGORY_CHOICES = [
        ('entradas', 'Entradas'),
        ('sopas', 'Sopas'),
        ('carne', 'Carne'),
        ('peixe', 'Peixe'),
        ('sobremesa', 'Sobremesa'),
    ]

    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    # Ingredients as comma-separated text — sufficient for display; no need for a
    # full Ingredient model since we don't track stock or allergens in this scope.
    ingredients = models.TextField(
        blank=True,
        help_text="Comma-separated list of ingredients"
    )
    price = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)
    is_available = models.BooleanField(default=True)

    class Meta:
        ordering = ['category', 'name']

    def __str__(self):
        return f"{self.name} ({self.get_category_display()})"


class Order(models.Model):
    """A customer order, linked to a table number."""

    # Status pipeline matches the kitchen Kanban columns exactly.
    STATUS_CHOICES = [
        ('order_preview', 'Order Preview'),
        ('preparing', 'Preparing'),
        ('cooling_down', 'Cooling Down'),
        ('ready_to_serve', 'Ready to Serve'),
        ('concluded', 'Concluded'),
    ]

    table_number = models.PositiveIntegerField()
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='order_preview'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # Optional notes field — goes beyond requirements, useful in a real restaurant.
    notes = models.TextField(blank=True, default='')

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Order #{self.id} — Table {self.table_number} ({self.get_status_display()})"


class OrderLine(models.Model):
    """
    Junction between Order and MenuItem. Each line represents
    one dish selection with its quantity.
    """
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name='lines'  # Access via order.lines.all()
    )
    menu_item = models.ForeignKey(
        MenuItem,
        on_delete=models.PROTECT  # Prevent deleting a dish that's part of an order
    )
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        # Prevent duplicate lines for the same dish in one order.
        unique_together = ['order', 'menu_item']

    def __str__(self):
        return f"{self.quantity}x {self.menu_item.name} (Order #{self.order_id})"
