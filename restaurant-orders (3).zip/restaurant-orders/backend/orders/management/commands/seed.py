"""
Management command to seed the database with sample menu data.
Run with: python manage.py seed

Uses Portuguese-inspired dishes to match the restaurant theme.
Idempotent: clears existing menu items before re-seeding.
"""
from django.core.management.base import BaseCommand
from orders.models import MenuItem


MENU_DATA = [
    # ── Entradas ──
    {
        'name': 'Pastéis de Bacalhau',
        'description': 'Bolinhos crocantes de bacalhau desfiado com batata, salsa e um toque de noz-moscada.',
        'category': 'entradas',
        'ingredients': 'Bacalhau, Batata, Ovo, Salsa, Cebola, Noz-moscada',
        'price': 8.50,
    },
    {
        'name': 'Alheira Frita',
        'description': 'Alheira de Mirandela frita com ovo estrelado e salada fresca.',
        'category': 'entradas',
        'ingredients': 'Alheira, Ovo, Alface, Tomate, Azeite',
        'price': 7.00,
    },
    {
        'name': 'Pimentos Padron',
        'description': 'Pimentos verdes salteados em azeite com flor de sal.',
        'category': 'entradas',
        'ingredients': 'Pimentos Padron, Azeite, Flor de sal',
        'price': 6.00,
    },
    {
        'name': 'Tábua de Queijos e Enchidos',
        'description': 'Seleção de queijos regionais e enchidos tradicionais portugueses.',
        'category': 'entradas',
        'ingredients': 'Queijo da Serra, Queijo de Azeitão, Chouriço, Presunto, Pão',
        'price': 14.00,
    },

    # ── Sopas ──
    {
        'name': 'Caldo Verde',
        'description': 'Sopa tradicional minhota com couve galega finamente cortada e rodelas de chouriço.',
        'category': 'sopas',
        'ingredients': 'Batata, Couve galega, Chouriço, Cebola, Alho, Azeite',
        'price': 5.00,
    },
    {
        'name': 'Sopa de Peixe',
        'description': 'Sopa rica com mistura de peixes, tomate e coentros.',
        'category': 'sopas',
        'ingredients': 'Peixe variado, Tomate, Cebola, Coentros, Batata, Azeite',
        'price': 6.50,
    },
    {
        'name': 'Creme de Espargos',
        'description': 'Creme aveludado de espargos verdes com croutons.',
        'category': 'sopas',
        'ingredients': 'Espargos, Cebola, Natas, Croutons, Manteiga',
        'price': 5.50,
    },

    # ── Carne ──
    {
        'name': 'Secretos de Porco Preto',
        'description': 'Secretos de porco ibérico grelhados com batata-doce assada e legumes.',
        'category': 'carne',
        'ingredients': 'Secretos de porco preto, Batata-doce, Pimentos, Azeite, Alho, Sal grosso',
        'price': 18.00,
    },
    {
        'name': 'Bife à Portuguesa',
        'description': 'Bife de vaca com molho de mostarda, presunto e ovo a cavalo.',
        'category': 'carne',
        'ingredients': 'Bife de vaca, Presunto, Ovo, Mostarda, Batata frita, Alho',
        'price': 16.50,
    },
    {
        'name': 'Arroz de Pato',
        'description': 'Arroz de pato no forno com chouriço e hortelã.',
        'category': 'carne',
        'ingredients': 'Pato, Arroz, Chouriço, Hortelã, Cebola, Azeite',
        'price': 15.00,
    },
    {
        'name': 'Cozido à Portuguesa',
        'description': 'Prato tradicional com carnes variadas, enchidos e legumes cozidos.',
        'category': 'carne',
        'ingredients': 'Carne de vaca, Frango, Chouriço, Farinheira, Couve, Cenoura, Batata, Nabo',
        'price': 17.50,
    },

    # ── Peixe ──
    {
        'name': 'Bacalhau à Brás',
        'description': 'Bacalhau desfiado com ovos, batata palha e azeitonas.',
        'category': 'peixe',
        'ingredients': 'Bacalhau, Ovos, Batata palha, Cebola, Azeitonas, Salsa',
        'price': 15.00,
    },
    {
        'name': 'Polvo à Lagareiro',
        'description': 'Polvo grelhado com batata a murro e azeite de alho.',
        'category': 'peixe',
        'ingredients': 'Polvo, Batata, Azeite, Alho, Coentros',
        'price': 22.00,
    },
    {
        'name': 'Filetes de Robalo',
        'description': 'Filetes de robalo grelhados com legumes salteados e molho de limão.',
        'category': 'peixe',
        'ingredients': 'Robalo, Limão, Espargos, Tomate cherry, Azeite, Alho',
        'price': 18.50,
    },
    {
        'name': 'Cataplana de Marisco',
        'description': 'Cataplana algarvia com amêijoas, camarões e tamboril.',
        'category': 'peixe',
        'ingredients': 'Amêijoas, Camarão, Tamboril, Tomate, Cebola, Pimento, Vinho branco, Coentros',
        'price': 25.00,
    },

    # ── Sobremesa ──
    {
        'name': 'Pastel de Nata',
        'description': 'O clássico pastel de nata com massa folhada crocante e creme de ovos.',
        'category': 'sobremesa',
        'ingredients': 'Massa folhada, Gemas de ovo, Açúcar, Leite, Farinha, Canela',
        'price': 3.00,
    },
    {
        'name': 'Mousse de Chocolate',
        'description': 'Mousse suave de chocolate negro com raspas de chocolate.',
        'category': 'sobremesa',
        'ingredients': 'Chocolate negro, Ovos, Açúcar, Natas',
        'price': 5.50,
    },
    {
        'name': 'Pudim Abade de Priscos',
        'description': 'Pudim conventual com toucinho, porto e calda de caramelo.',
        'category': 'sobremesa',
        'ingredients': 'Açúcar, Gemas de ovo, Toucinho, Vinho do Porto, Canela, Limão',
        'price': 6.00,
    },
    {
        'name': 'Serradura',
        'description': 'Sobremesa gelada de natas e bolacha Maria triturada.',
        'category': 'sobremesa',
        'ingredients': 'Natas, Leite condensado, Bolacha Maria',
        'price': 5.00,
    },
]


class Command(BaseCommand):
    help = 'Seed the database with sample menu items'

    def handle(self, *args, **options):
        self.stdout.write('Clearing existing menu items...')
        MenuItem.objects.all().delete()

        self.stdout.write('Seeding menu items...')
        items = [MenuItem(**data) for data in MENU_DATA]
        MenuItem.objects.bulk_create(items)

        self.stdout.write(self.style.SUCCESS(
            f'Successfully created {len(items)} menu items across 5 categories.'
        ))
