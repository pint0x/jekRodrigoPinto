"""
Serializers for the REST API.

Design notes:
- MenuItemSerializer: flat representation, ingredients split into a list for frontend convenience.
- OrderLineSerializer: nested under Order, includes full menu_item details for the kitchen view.
- OrderSerializer: handles both read (nested lines with dish details) and write (accepts
  a list of {menu_item_id, quantity} pairs). This dual behaviour avoids needing separate
  endpoints for creation vs reading.
- OrderCreateSerializer: write-only serializer specifically for order creation,
  keeping validation logic clean and separated from read concerns.
"""
from rest_framework import serializers
from .models import MenuItem, Order, OrderLine


class MenuItemSerializer(serializers.ModelSerializer):
    """Serialize a menu item. Splits ingredients into a list for easier frontend rendering."""
    ingredients_list = serializers.SerializerMethodField()

    class Meta:
        model = MenuItem
        fields = ['id', 'name', 'description', 'category', 'ingredients', 'ingredients_list', 'price', 'is_available']

    def get_ingredients_list(self, obj):
        """Convert comma-separated ingredients to a clean list."""
        if not obj.ingredients:
            return []
        return [i.strip() for i in obj.ingredients.split(',') if i.strip()]


class OrderLineReadSerializer(serializers.ModelSerializer):
    """Read-only serializer for order lines — includes full dish info for the kitchen dashboard."""
    menu_item = MenuItemSerializer(read_only=True)

    class Meta:
        model = OrderLine
        fields = ['id', 'menu_item', 'quantity']


class OrderReadSerializer(serializers.ModelSerializer):
    """
    Read serializer for orders. Nests full order lines with dish details.
    Used by the kitchen dashboard to display complete order info.
    """
    lines = OrderLineReadSerializer(many=True, read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = Order
        fields = ['id', 'table_number', 'status', 'status_display', 'created_at', 'updated_at', 'notes', 'lines']


class OrderLineCreateSerializer(serializers.Serializer):
    """Validates a single line item when creating an order."""
    menu_item_id = serializers.IntegerField()
    quantity = serializers.IntegerField(min_value=1)


class OrderCreateSerializer(serializers.Serializer):
    """
    Write-only serializer for creating orders.
    Accepts table_number, optional notes, and a list of line items.
    Validates that all referenced menu items exist and are available.
    """
    table_number = serializers.IntegerField(min_value=1)
    notes = serializers.CharField(required=False, allow_blank=True, default='')
    lines = OrderLineCreateSerializer(many=True)

    def validate_lines(self, value):
        """Ensure at least one line item and all menu items exist."""
        if not value:
            raise serializers.ValidationError("Order must contain at least one item.")

        menu_item_ids = [line['menu_item_id'] for line in value]
        existing_items = MenuItem.objects.filter(id__in=menu_item_ids, is_available=True)
        existing_ids = set(existing_items.values_list('id', flat=True))

        missing = set(menu_item_ids) - existing_ids
        if missing:
            raise serializers.ValidationError(
                f"Menu items not found or unavailable: {missing}"
            )
        return value

    def create(self, validated_data):
        """Create the order and its associated line items in a single transaction."""
        lines_data = validated_data.pop('lines')
        order = Order.objects.create(**validated_data)

        order_lines = [
            OrderLine(
                order=order,
                menu_item_id=line['menu_item_id'],
                quantity=line['quantity']
            )
            for line in lines_data
        ]
        # bulk_create is more efficient than creating one by one.
        OrderLine.objects.bulk_create(order_lines)
        return order


class OrderStatusUpdateSerializer(serializers.Serializer):
    """Validates status transitions for the kitchen Kanban board."""
    status = serializers.ChoiceField(choices=Order.STATUS_CHOICES)
