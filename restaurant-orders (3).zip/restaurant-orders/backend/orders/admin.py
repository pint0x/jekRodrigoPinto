"""Admin configuration — useful for debugging and manual data management."""
from django.contrib import admin
from .models import MenuItem, Order, OrderLine


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'is_available']
    list_filter = ['category', 'is_available']


class OrderLineInline(admin.TabularInline):
    model = OrderLine
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'table_number', 'status', 'created_at']
    list_filter = ['status']
    inlines = [OrderLineInline]
