"""
API views for the Restaurant Order Management System.

Architecture:
- Function-based views for simplicity and readability (no need for ViewSet
  complexity with only a handful of endpoints).
- SSE endpoint for real-time kitchen updates — chosen over WebSockets because
  the data flow is unidirectional (server → client). SSE is simpler to implement,
  works over standard HTTP, and doesn't require additional infrastructure (no
  channels/redis/daphne). See TECHNICAL_DECISIONS.md for full rationale.
"""
import json
import time
import threading
from django.http import StreamingHttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST, require_http_methods
from rest_framework.parsers import JSONParser

from .models import MenuItem, Order, OrderLine
from .serializers import (
    MenuItemSerializer,
    OrderReadSerializer,
    OrderCreateSerializer,
    OrderStatusUpdateSerializer,
)

# ──────────────────────────────────────────────
# SSE: Simple event broadcasting for real-time
# ──────────────────────────────────────────────

# In-memory list of connected SSE clients. Each client is a threading.Event
# that gets set when new data is available. This is lightweight and fits
# Django's sync model without needing Channels/Redis.
_sse_clients = []
_sse_lock = threading.Lock()


def _notify_clients():
    """Signal all connected SSE clients that new data is available."""
    with _sse_lock:
        for event in _sse_clients:
            event.set()


def sse_stream(request):
    """
    SSE endpoint: GET /api/orders/stream/
    Clients connect and receive a 'refresh' event whenever an order is
    created or updated. The client then fetches the latest data.

    Why signal-based instead of sending full payloads:
    - Simpler: no need to serialize order data in the SSE stream.
    - Client already has a fetch function; it just needs a trigger.
    - Avoids sync issues between SSE payload and actual DB state.
    """
    def event_stream():
        client_event = threading.Event()
        with _sse_lock:
            _sse_clients.append(client_event)
        try:
            # Send initial connection confirmation
            yield 'data: {"type": "connected"}\n\n'
            while True:
                # Wait for a notification or timeout (heartbeat every 15s)
                triggered = client_event.wait(timeout=15)
                if triggered:
                    yield 'data: {"type": "refresh"}\n\n'
                    client_event.clear()
                else:
                    # Heartbeat to keep connection alive
                    yield ': heartbeat\n\n'
        except GeneratorExit:
            pass
        finally:
            with _sse_lock:
                _sse_clients.remove(client_event)

    response = StreamingHttpResponse(
        event_stream(),
        content_type='text/event-stream'
    )
    response['Cache-Control'] = 'no-cache'
    response['X-Accel-Buffering'] = 'no'  # Disable nginx buffering if proxied
    return response


# ──────────────────────────────────────────────
# Menu endpoints
# ──────────────────────────────────────────────

@require_GET
def menu_list(request):
    """
    GET /api/menu/
    Returns the full menu, optionally filtered by category.
    Query param: ?category=entradas
    """
    queryset = MenuItem.objects.filter(is_available=True)

    category = request.GET.get('category')
    if category:
        queryset = queryset.filter(category=category)

    serializer = MenuItemSerializer(queryset, many=True)
    return JsonResponse(serializer.data, safe=False)


@require_GET
def menu_detail(request, pk):
    """GET /api/menu/<id>/ — single menu item with full details."""
    try:
        item = MenuItem.objects.get(pk=pk, is_available=True)
    except MenuItem.DoesNotExist:
        return JsonResponse({'error': 'Menu item not found'}, status=404)

    serializer = MenuItemSerializer(item)
    return JsonResponse(serializer.data)


# ──────────────────────────────────────────────
# Order endpoints
# ──────────────────────────────────────────────

@csrf_exempt
@require_POST
def order_create(request):
    """
    POST /api/orders/
    Creates a new order with line items.
    Body: { table_number: int, notes?: string, lines: [{menu_item_id, quantity}] }
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

    serializer = OrderCreateSerializer(data=data)
    if not serializer.is_valid():
        return JsonResponse({'errors': serializer.errors}, status=400)

    order = serializer.save()

    # Return the full order with nested line details
    read_serializer = OrderReadSerializer(order)

    # Notify SSE clients that a new order arrived
    _notify_clients()

    return JsonResponse(read_serializer.data, status=201)


@require_GET
def order_list(request):
    """
    GET /api/orders/
    Returns all orders. Optionally filter by status.
    Query param: ?status=preparing
    """
    queryset = Order.objects.prefetch_related('lines__menu_item').all()

    status = request.GET.get('status')
    if status:
        queryset = queryset.filter(status=status)

    serializer = OrderReadSerializer(queryset, many=True)
    return JsonResponse(serializer.data, safe=False)


@require_GET
def order_detail(request, pk):
    """GET /api/orders/<id>/ — single order with all line details."""
    try:
        order = Order.objects.prefetch_related('lines__menu_item').get(pk=pk)
    except Order.DoesNotExist:
        return JsonResponse({'error': 'Order not found'}, status=404)

    serializer = OrderReadSerializer(order)
    return JsonResponse(serializer.data)


@csrf_exempt
@require_http_methods(["PATCH"])
def order_update_status(request, pk):
    """
    PATCH /api/orders/<id>/status/
    Updates the order status (moves it between Kanban columns).
    Body: { status: "preparing" | "cooling_down" | "ready_to_serve" | "concluded" }
    """
    try:
        order = Order.objects.get(pk=pk)
    except Order.DoesNotExist:
        return JsonResponse({'error': 'Order not found'}, status=404)

    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

    serializer = OrderStatusUpdateSerializer(data=data)
    if not serializer.is_valid():
        return JsonResponse({'errors': serializer.errors}, status=400)

    order.status = serializer.validated_data['status']
    order.save()

    read_serializer = OrderReadSerializer(order)

    # Notify SSE clients that an order status changed
    _notify_clients()

    return JsonResponse(read_serializer.data)
