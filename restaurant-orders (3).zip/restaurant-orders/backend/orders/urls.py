"""
URL routes for the orders API.

Follows REST conventions:
- GET    /api/menu/              → list menu items
- GET    /api/menu/<id>/         → menu item detail
- POST   /api/orders/            → create order
- GET    /api/orders/            → list orders (kitchen dashboard)
- GET    /api/orders/<id>/       → order detail
- PATCH  /api/orders/<id>/status/ → update order status (Kanban transitions)
- GET    /api/orders/stream/     → SSE stream for real-time updates
"""
from django.urls import path
from . import views

urlpatterns = [
    # Menu
    path('menu/', views.menu_list, name='menu-list'),
    path('menu/<int:pk>/', views.menu_detail, name='menu-detail'),

    # Orders
    path('orders/', views.order_create, name='order-create'),  # POST
    path('orders/list/', views.order_list, name='order-list'),  # GET
    path('orders/<int:pk>/', views.order_detail, name='order-detail'),
    path('orders/<int:pk>/status/', views.order_update_status, name='order-update-status'),

    # SSE stream
    path('orders/stream/', views.sse_stream, name='order-stream'),
]
