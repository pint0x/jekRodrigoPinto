"""
Root URL configuration.
All API routes are namespaced under /api/ for clean separation.
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('orders.urls')),
]
