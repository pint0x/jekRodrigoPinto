# Decisões Técnicas — Guia de Defesa

Este documento explica **como as coisas funcionam**, **porquê foram tomadas certas decisões**, e **quais os trade-offs envolvidos**. Serve como preparação para defender o código com confiança perante questões técnicas.

---

## 1. Escolha do Stack

### Backend: Django + Django REST Framework

**Porquê Django?**
- **ORM integrado**: o modelo de dados (MenuItem → OrderLine → Order) mapeia-se diretamente para modelos Django com relações FK. Não preciso de configurar SQLAlchemy ou escrever SQL manual.
- **Migrações automáticas**: `makemigrations` + `migrate` gere o schema da DB automaticamente. Com FastAPI teria de configurar Alembic separadamente.
- **Admin gratuito**: `admin.py` com 10 linhas dá-me uma interface de gestão de dados para debug sem esforço extra.
- **DRF**: serializers tratam de validação de input + formatação de output JSON de forma declarativa.

**Alternativas consideradas:**
- **FastAPI**: mais rápido (async nativo), melhor para APIs puras. Mas para este scope, o ecossistema Django (ORM, admin, management commands) poupa mais tempo do que o ganho de performance do FastAPI. FastAPI seria melhor se o sistema precisasse de alta concorrência ou fosse puramente uma API sem modelo de dados complexo.
- **Express.js**: permitiria usar JavaScript full-stack, mas o ORM (Sequelize/Prisma) é menos maduro que o Django ORM para este tipo de modelação relacional.

**Trade-off aceite**: Django é mais pesado que FastAPI para uma API simples, mas a produtividade e as ferramentas integradas compensam neste scope.

### Frontend: React + TypeScript + Vite

**Porquê React?**
- Standard da indústria, ecossistema gigante de bibliotecas (ex: @dnd-kit para drag-and-drop).
- Modelo de componentes adequado para as duas interfaces distintas (cliente + cozinha).
- Hooks (useState, useEffect, useCallback) são suficientes para a gestão de estado neste scope.

**Porquê TypeScript?**
- Type safety: os tipos `MenuItem`, `Order`, `CartItem` são partilhados entre componentes, evitando bugs de runtime (ex: aceder a `order.lines` quando deveria ser `order.items`).
- Autocompleção no editor: acelera o desenvolvimento.
- Documenta implicitamente a API — os tipos em `types/index.ts` servem como contrato entre frontend e backend.

**Porquê Vite (e não CRA)?**
- CRA está deprecado e usa Webpack (lento).
- Vite usa esbuild para transformação e Rollup para build — HMR instantâneo (<100ms vs. segundos com CRA).
- Configuração mínima, suporta TypeScript e React out-of-the-box.

**Alternativas:**
- **Angular**: mais opinativo, TypeScript nativo, mas o boilerplate é desproporcionado para um projeto deste scope (modules, services, dependency injection).
- **Vue**: seria igualmente válido, mas React tem maior ecossistema de componentes de drag-and-drop.

### Base de Dados: SQLite

**Porquê?**
- **Zero configuração**: basta correr `migrate` e a DB é criada como ficheiro. Qualquer reviewer pode correr o projeto sem instalar PostgreSQL/Docker.
- **Suficiente para o scope**: um restaurante com 12 mesas e dezenas de pedidos por dia não precisa de concorrência avançada.
- **Default do Django**: funciona nativamente sem configuração extra em `settings.py`.

**Quando escolher PostgreSQL?**
- Múltiplos processos/workers a escrever simultaneamente (SQLite tem write-lock global).
- Full-text search, JSON querying, ou extensões como PostGIS.
- Produção com múltiplas instâncias de servidor.

**Trade-off**: SQLite não suporta escrita concorrente — se 50 pedidos chegassem simultaneamente, haveria contenção. Aceitável para demo/avaliação.

---

## 2. Modelo de Dados

### Esquema

```
MenuItem (id, name, description, category, ingredients, price, is_available)
    ↑
OrderLine (id, order_id FK, menu_item_id FK, quantity)
    ↓
Order (id, table_number, status, created_at, updated_at, notes)
```

### Decisões chave:

**Categorias como CharField com choices (e não como tabela separada):**
- As 5 categorias são fixas e definidas no enunciado. Uma tabela `Category` com FK seria normalização excessiva para dados estáticos que nunca mudam em runtime.
- Se no futuro o restaurante quisesse criar/editar categorias dinamicamente, então uma tabela separada faria sentido.

**Ingredientes como TextField (e não como relação M2M):**
- Os ingredientes são apenas para display na cozinha. Não precisamos de filtrar por ingrediente, calcular stock, ou gerir alergénios a nível de BD.
- Uma relação M2M `MenuItem ↔ Ingredient` seria correta se precisássemos de: filtro por alergénico, gestão de stock, ou partilha de ingredientes entre pratos.
- Trade-off: se um ingrediente muda de nome, temos de atualizar em cada prato. Aceitável para dados seed estáticos.

**OrderLine com unique_together (order, menu_item):**
- Impede duplicados: se o cliente adiciona 2x "Bacalhau à Brás", temos uma linha com `quantity=2`, não duas linhas com `quantity=1`.
- Simplifica queries e serialização.

**on_delete=PROTECT em OrderLine → MenuItem:**
- Impede a eliminação de um prato que faz parte de um pedido existente. `CASCADE` apagaria silenciosamente linhas de pedidos históricos.

**Campo `notes` no Order:**
- Vai além dos requisitos, mas é trivial de implementar e extremamente útil num restaurante real (alergias, preferências).

---

## 3. Design da API

### Convenções REST seguidas:

- **Substantivos no URL**: `/api/menu/`, `/api/orders/` (não `/api/getMenu`).
- **Verbos HTTP corretos**: GET para leitura, POST para criação, PATCH para atualização parcial.
- **Códigos HTTP semânticos**: 200 (OK), 201 (Created), 400 (Bad Request), 404 (Not Found).
- **Respostas JSON consistentes**: todos os endpoints devolvem JSON com a mesma estrutura.

### Serializers separados para leitura vs. escrita:

- **OrderReadSerializer**: devolve o pedido com linhas nested e detalhes completos do prato (nome, ingredientes). É o que a cozinha precisa.
- **OrderCreateSerializer**: aceita `{ table_number, lines: [{menu_item_id, quantity}] }`. Não precisa de receber o objeto completo do prato — apenas o ID.
- **Porquê separar?** Um único serializer com `read_only` e `write_only` fields fica confuso rapidamente. Separar torna a validação explícita e o código mais legível.

### Endpoints de status separados:

- `PATCH /api/orders/:id/status/` em vez de `PUT /api/orders/:id/` com o body completo.
- Mais granular: a cozinha só precisa de mudar o estado, não de reenviar todo o pedido.
- Segue o princípio de least privilege — o endpoint faz uma coisa e fá-la bem.

---

## 4. Tempo Real: SSE (Server-Sent Events)

### Porquê SSE e não WebSockets?

**A natureza do fluxo de dados determina a escolha:**
- O fluxo é **unidirecional**: o servidor notifica a cozinha quando há alterações. A cozinha não precisa de enviar dados em tempo real ao servidor (as atualizações de estado são feitas via REST/PATCH).
- SSE é perfeito para este padrão: push-only, server → client.

**Vantagens do SSE:**
1. **Simplicidade**: funciona sobre HTTP standard (não precisa de upgrade de protocolo como WebSockets).
2. **Auto-reconexão**: o browser reconecta automaticamente se a ligação cair. Com WebSockets, temos de implementar reconexão manual.
3. **Sem infraestrutura extra**: Django pode servir SSE com `StreamingHttpResponse`. WebSockets em Django requerem Channels + ASGI + Redis + Daphne.
4. **Firewall-friendly**: SSE usa porta 80/443 como qualquer request HTTP. WebSockets podem ser bloqueados por proxies empresariais.

**Quando escolher WebSockets?**
- Comunicação bidirecional (ex: chat, jogos multiplayer).
- Alta frequência de mensagens em ambas as direções.
- Necessidade de protocolos binários.

**Implementação:**
- Usamos um padrão signal-based: o SSE stream envia apenas `{"type": "refresh"}`. O cliente então faz fetch dos dados atualizados via REST.
- Porquê não enviar os dados completos no SSE? Simplicidade e consistência — evita dessincronização entre o payload SSE e o estado real da DB. O cliente já tem a função de fetch; só precisa de um trigger.
- Heartbeat a cada 15 segundos mantém a conexão viva através de proxies.

**Trade-off**: a implementação atual usa threads em memória (lista de `threading.Event`). Isto funciona com um único processo Django. Com múltiplos workers (gunicorn com vários processos), cada worker teria a sua lista de clientes. Solução para produção: usar Redis pub/sub para sincronizar entre workers.

---

## 5. Frontend: Gestão de Estado

### useState é suficiente (sem Redux/Zustand)

**Análise do estado da aplicação:**
- **ClientOrderPage**: estado local (cart, tableNumber, menu) que não é partilhado com outros componentes.
- **KitchenDashboardPage**: estado local (orders) que é fetched do servidor.
- Não há estado global partilhado entre as duas páginas.

**Quando usar Redux/Zustand?**
- Estado partilhado entre muitos componentes em níveis diferentes da árvore.
- Cache de dados do servidor com invalidação complexa (nesse caso, React Query seria melhor).
- Undo/redo, time-travel debugging.

**Trade-off**: se o sistema crescesse (ex: múltiplas páginas que precisam de aceder aos pedidos), React Query ou Zustand seriam adequados. Para este scope, hooks locais são a solução mais simples e legível.

### useCallback para handlers

- `addToCart`, `updateQuantity`, `removeFromCart` estão wrapped em `useCallback` para evitar re-renders desnecessários dos componentes filhos.
- Não é crítico neste scope (poucos items), mas é boa prática e demonstra awareness de performance.

---

## 6. Drag-and-Drop: @dnd-kit

### Porquê @dnd-kit e não react-beautiful-dnd?

- **react-beautiful-dnd** está **descontinuado** pela Atlassian. Sem atualizações desde 2022.
- **@dnd-kit** é ativamente mantido, mais leve, e tem melhor suporte para:
  - Acessibilidade (keyboard navigation, screen readers)
  - Múltiplos tipos de interação (pointer, keyboard, touch)
  - Customização de collision detection

### Implementação:

- **DndContext** wraps o board inteiro.
- **useDroppable** em cada coluna (o `id` é o status key: `'preparing'`).
- **useSortable** em cada card (permite drag dentro e entre colunas).
- **PointerSensor com activationConstraint** de 8px: evita que um click normal (para abrir o modal) seja interpretado como drag.
- **DragOverlay**: mostra um "ghost" card enquanto se arrasta, melhorando o feedback visual.

---

## 7. Styling: CSS Puro

### Porquê não Tailwind?

- Para ~400 linhas de CSS, Tailwind adicionaria uma dependência de build e classes que tornam o JSX menos legível (ex: `className="flex items-center justify-between gap-4 p-4 bg-white border rounded-lg shadow-sm"`).
- CSS puro com custom properties (`--accent`, `--border`, etc.) dá capacidade de temas.
- Qualquer developer pode ler e auditar o CSS sem conhecer Tailwind.

**Quando escolher Tailwind?**
- Equipas grandes onde consistência de estilos é difícil de manter.
- Projetos com design system complexo.
- Prototipagem rápida onde a velocidade de styling é crítica.

### Porquê não CSS Modules ou styled-components?

- CSS Modules: boa escolha para evitar colisões de nomes. Neste scope com ~15 componentes, prefixos semânticos (`.order-card-*`, `.cart-*`) são suficientes.
- styled-components: runtime CSS-in-JS com overhead de performance. A tendência atual é para soluções zero-runtime (Tailwind, CSS Modules).

---

## 8. Funcionalidades Bónus Implementadas

1. **SSE (tempo real)**: o dashboard atualiza automaticamente quando um novo pedido é criado ou um estado muda.
2. **Kanban drag-and-drop**: arrastar cartões entre colunas com @dnd-kit.
3. **Campo de notas**: o cliente pode adicionar notas ao pedido (alergias, preferências).
4. **Preço e total**: cada prato tem preço, o carrinho mostra o total.
5. **Indicador de tempo**: cada cartão mostra há quanto tempo o pedido foi recebido.
6. **Indicador de estado SSE**: a cozinha vê se a ligação em tempo real está ativa.
7. **Responsivo**: layout adapta-se a ecrãs mais pequenos.
8. **Feedback adequado**: mensagens de sucesso/erro com auto-dismiss.

---

## 9. Perguntas Frequentes de Entrevista

### "Porquê não usaste autenticação?"
O enunciado diz explicitamente "não é necessário implementar autenticação ou contas de utilizador". Implementar auth seria over-engineering e penalizado.

### "Como escalarias este sistema?"
1. **DB**: migrar de SQLite para PostgreSQL.
2. **SSE**: usar Redis pub/sub para sincronizar entre múltiplos workers Django.
3. **Deploy**: Docker + docker-compose, com nginx como reverse proxy.
4. **Frontend**: build estático servido pelo nginx, API no Django via gunicorn.
5. **Cache**: Redis para cache de menu (muda raramente).

### "Porquê function-based views e não ViewSets?"
- 6 endpoints simples não justificam a abstração de ViewSets + Router.
- FBVs são mais explícitas — vê-se exatamente o que cada endpoint faz.
- ViewSets são úteis quando temos CRUD completo com padrões repetitivos.

### "O modelo de dados está normalizado?"
Sim: 3NF. Cada facto é armazenado uma vez. Excepções intencionais:
- `ingredients` como texto: desnormalizado por design (ver secção 2).
- `category` como CharField: choices fixos, não justifica tabela própria.

### "E se dois cozinheiros moverem o mesmo pedido ao mesmo tempo?"
Last-write-wins com a implementação atual. Soluções para produção:
- Optimistic locking: adicionar `version` field, rejeitar updates com version desatualizada.
- Ou: usar `updated_at` como etag e devolver 409 Conflict.

### "Porquê bulk_create para order lines?"
Uma query INSERT em vez de N queries. Com 5 pratos por pedido, a diferença é pequena, mas demonstra awareness de performance e boas práticas com ORMs.

---

## 10. Resumo de Trade-offs

| Decisão | Benefício | Custo |
|---------|-----------|-------|
| SQLite | Zero config, portátil | Sem concorrência de escrita |
| SSE (não WebSockets) | Simples, auto-reconnect | Unidirecional apenas |
| CSS puro (não Tailwind) | Legível, zero build | Mais verbose |
| useState (não Redux) | Simples, local | Não escala para estado global |
| CharField choices (não FK) | Menos joins, mais simples | Categorias fixas |
| Ingredients como texto | Simples, suficiente para display | Não filtrável por ingrediente |
| FBVs (não ViewSets) | Explícitas, legíveis | Mais boilerplate se crescer |
| Signal-based SSE | Consistência com REST | Extra round-trip para dados |
