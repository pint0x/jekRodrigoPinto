import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// O frontend chama sempre "/api/...". O Vite reencaminha esses pedidos para
// o Django. Para o browser, frontend e backend parecem a mesma origem, por
// isso não é preciso configurar CORS.
const proxy = {
  '/api': {
    target: process.env.API_URL ?? 'http://127.0.0.1:8000',
    changeOrigin: true,
  },
}

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Aceita ligações da rede local, para votar a partir do telemóvel.
    host: true,
    proxy,
  },
  preview: { port: 4173, host: true, proxy },
})
