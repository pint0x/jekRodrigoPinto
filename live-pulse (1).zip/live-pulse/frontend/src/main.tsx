import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// Fonte instalada pelo npm (não depende de um CDN externo).
import '@fontsource-variable/bricolage-grotesque/opsz.css'
import './styles.css'
import App from './App'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
