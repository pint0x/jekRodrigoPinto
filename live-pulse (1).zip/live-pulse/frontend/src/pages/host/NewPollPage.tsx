import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router'
import { ApiError } from '../../api/client'
import { createPoll } from '../../api/polls'
import { BackLink } from '../../components/BackLink'
import { useDocumentTitle } from '../../lib/routing'

const MIN_OPTIONS = 2
const MAX_OPTIONS = 5

/** Cada opção tem um id local, para o React não confundir inputs ao remover uma do meio. */
interface OptionDraft {
  key: number
  text: string
}

interface FormErrors {
  question?: string
  /** Erro da lista inteira (ex.: opções repetidas). */
  options?: string
  /** Erro de uma opção específica, pela posição. */
  optionAt?: Record<number, string>
  /** Erro que não pertence a nenhum campo (ex.: sem ligação). */
  form?: string
}

let nextKey = 0
const emptyOption = (): OptionDraft => ({ key: nextKey++, text: '' })

export function NewPollPage() {
  useDocumentTitle('Nova votação')
  const navigate = useNavigate()

  const [question, setQuestion] = useState('')
  const [options, setOptions] = useState<OptionDraft[]>(() => [emptyOption(), emptyOption()])
  const [errors, setErrors] = useState<FormErrors>({})
  const [submitting, setSubmitting] = useState(false)
  const [focusKey, setFocusKey] = useState<number | null>(null)

  // Ao editar um campo, o erro dele desaparece (volta a ser validado ao submeter).
  function clearOptionErrors() {
    setErrors(({ question, form }) => ({ question, form }))
  }

  function updateOption(key: number, text: string) {
    setOptions((current) => current.map((option) => (option.key === key ? { ...option, text } : option)))
    clearOptionErrors()
  }

  function addOption() {
    const option = emptyOption()
    setOptions((current) => [...current, option])
    setFocusKey(option.key)
  }

  function removeOption(key: number) {
    setOptions((current) => current.filter((option) => option.key !== key))
    clearOptionErrors()
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    const payload = { question: question.trim(), options: options.map((option) => option.text.trim()) }

    // Validação no browser, para feedback imediato. O backend valida tudo
    // outra vez: é ele a fonte de verdade.
    const localErrors = validate(payload.question, payload.options)
    setErrors(localErrors)
    if (Object.keys(localErrors).length > 0) return

    setSubmitting(true)
    try {
      const poll = await createPoll(payload)
      navigate(`/anfitriao/votacoes/${poll.id}`)
    } catch (err) {
      setErrors(err instanceof ApiError ? errorsFromApi(err) : { form: String(err) })
      setSubmitting(false)
    }
  }

  const optionErrorAt = (index: number) => errors.optionAt?.[index]

  return (
    <>
      <BackLink to="/anfitriao">Todas as votações</BackLink>
      <h1 className="page-title">Nova votação</h1>
      <p className="page-intro muted">A votação fica em rascunho. Só aparece ao público quando a abrires.</p>

      <form className="form" onSubmit={handleSubmit} noValidate>
        <div className="field">
          <label htmlFor="question" className="field__label">
            Pergunta
          </label>
          <input
            id="question"
            className="input"
            value={question}
            maxLength={200}
            placeholder="Ex.: Que tema queres na próxima palestra?"
            aria-invalid={errors.question ? true : undefined}
            aria-describedby={errors.question ? 'question-error' : undefined}
            onChange={(event) => {
              setQuestion(event.target.value)
              setErrors((current) => ({ ...current, question: undefined }))
            }}
            autoFocus
          />
          {errors.question && (
            <p id="question-error" className="field__error">
              {errors.question}
            </p>
          )}
        </div>

        <fieldset className="field field--group">
          <legend className="field__label">Opções</legend>
          <p className="field__hint">
            Entre {MIN_OPTIONS} e {MAX_OPTIONS} opções. Aparecem ao público por esta ordem.
          </p>

          <ol className="option-inputs">
            {options.map((option, index) => (
              <li key={option.key} className="option-input">
                <input
                  className="input"
                  value={option.text}
                  maxLength={100}
                  placeholder={`Opção ${index + 1}`}
                  aria-label={`Opção ${index + 1}`}
                  aria-invalid={optionErrorAt(index) ? true : undefined}
                  onChange={(event) => updateOption(option.key, event.target.value)}
                  autoFocus={option.key === focusKey}
                />
                {options.length > MIN_OPTIONS && (
                  <button
                    type="button"
                    className="icon-button"
                    aria-label={`Remover opção ${index + 1}`}
                    onClick={() => removeOption(option.key)}
                  >
                    ×
                  </button>
                )}
                {optionErrorAt(index) && <p className="field__error option-input__error">{optionErrorAt(index)}</p>}
              </li>
            ))}
          </ol>

          {errors.options && <p className="field__error">{errors.options}</p>}

          <div>
            <button
              type="button"
              className="button button--secondary"
              onClick={addOption}
              disabled={options.length >= MAX_OPTIONS}
            >
              Adicionar opção
            </button>
            {options.length >= MAX_OPTIONS && (
              <span className="field__hint inline-hint">Chegaste ao máximo de {MAX_OPTIONS} opções.</span>
            )}
          </div>
        </fieldset>

        {errors.form && (
          <p className="form-error" role="alert">
            {errors.form}
          </p>
        )}

        <div className="form__actions">
          <button type="submit" className="button button--large" disabled={submitting}>
            {submitting ? 'A criar…' : 'Criar votação'}
          </button>
          <Link to="/anfitriao" className="button button--secondary button--large">
            Cancelar
          </Link>
        </div>
      </form>
    </>
  )
}

/** As mesmas regras do backend (serializers.py), com as mesmas mensagens. */
function validate(question: string, options: string[]): FormErrors {
  const errors: FormErrors = {}
  if (!question) errors.question = 'A pergunta não pode estar vazia.'

  const optionAt: Record<number, string> = {}
  options.forEach((text, index) => {
    if (!text) optionAt[index] = 'Preenche esta opção ou remove-a.'
  })
  if (Object.keys(optionAt).length > 0) errors.optionAt = optionAt

  const filled = options.filter(Boolean).map((text) => text.toLocaleLowerCase('pt-PT'))
  if (new Set(filled).size !== filled.length) errors.options = 'Não podem existir opções repetidas.'

  return errors
}

/**
 * Converte os erros do DRF para o formato do formulário. As opções podem vir
 * como lista (erro da lista inteira) ou como objeto {posição: [mensagens]}.
 */
function errorsFromApi(error: ApiError): FormErrors {
  if (error.code !== 'validation_error') return { form: error.message }

  const { question, options } = error.fieldErrors as {
    question?: string[]
    options?: string[] | Record<string, string[]>
  }
  const errors: FormErrors = {}
  if (question) errors.question = question[0]
  if (Array.isArray(options)) {
    errors.options = options[0]
  } else if (options) {
    errors.optionAt = Object.fromEntries(Object.entries(options).map(([index, messages]) => [Number(index), messages[0]]))
  }
  if (Object.keys(errors).length === 0) errors.form = error.message
  return errors
}
