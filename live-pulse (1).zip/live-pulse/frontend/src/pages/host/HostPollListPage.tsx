import { Link } from 'react-router'
import { listHostPolls } from '../../api/polls'
import { ErrorNotice, Loading } from '../../components/Feedback'
import { StatusBadge } from '../../components/StatusBadge'
import { formatDate } from '../../lib/format'
import { useDocumentTitle } from '../../lib/routing'
import { useFetch } from '../../lib/useFetch'

/** Os totais de votos vão subindo sem recarregar a página. */
const REFRESH_MS = 5000

export function HostPollListPage() {
  useDocumentTitle('Painel do anfitrião')
  const { data: polls, error, loading, reload } = useFetch('host-polls', listHostPolls, REFRESH_MS)

  return (
    <>
      <div className="page-head">
        <h1 className="page-title">Votações</h1>
        <Link to="/anfitriao/nova" className="button">
          Nova votação
        </Link>
      </div>

      {error && <ErrorNotice error={error} onRetry={reload} />}
      {loading && <Loading />}

      {polls?.length === 0 && (
        <div className="empty">
          <p className="empty__title">Ainda não há votações.</p>
          <p className="muted">Cria a primeira. Fica em rascunho até a abrires ao público.</p>
        </div>
      )}

      {polls && polls.length > 0 && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Pergunta</th>
                <th scope="col">Estado</th>
                <th scope="col" className="num">
                  Votos
                </th>
                <th scope="col" className="col-date">
                  Criada
                </th>
              </tr>
            </thead>
            <tbody>
              {polls.map((poll) => (
                <tr key={poll.id}>
                  <td>
                    <Link to={`/anfitriao/votacoes/${poll.id}`} className="table__question">
                      {poll.question}
                    </Link>
                  </td>
                  <td>
                    <StatusBadge status={poll.status} />
                  </td>
                  <td className="num">{poll.total_votes}</td>
                  <td className="col-date muted">{formatDate(poll.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}
