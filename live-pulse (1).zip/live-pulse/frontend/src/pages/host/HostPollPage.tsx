import { useState } from 'react'
import { ApiError } from '../../api/client'
import { changePollStatus, getHostPoll } from '../../api/polls'
import type { PollResults, PollStatus } from '../../api/types'
import { BackLink } from '../../components/BackLink'
import { ErrorNotice, Loading, NotFound } from '../../components/Feedback'
import { ResultsBars } from '../../components/ResultsBars'
import { ShareLink } from '../../components/ShareLink'
import { LiveDot, StatusBadge } from '../../components/StatusBadge'
import { formatDate, publicPollUrl } from '../../lib/format'
import { useDocumentTitle, useIdParam } from '../../lib/routing'
import { useFetch } from '../../lib/useFetch'

/**
 * Nível 3: com a votação aberta, os resultados atualizam-se de 2 em 2 s
 * (polling). Em rascunho ou fechada não há nada a mudar, por isso para.
 */
const LIVE_REFRESH_MS = 2000

export function HostPollPage() {
  const pollId = useIdParam()
  const poll = useFetch(
    pollId === null ? null : `host-poll:${pollId}`,
    () => getHostPoll(pollId!),
    (data) => (data && data.status !== 'open' ? null : LIVE_REFRESH_MS),
  )
  useDocumentTitle(poll.data?.question)

  if (pollId === null || poll.error?.status === 404) {
    return <NotFound message="Esta votação não existe." backTo="/anfitriao" backLabel="Ver todas as votações" />
  }
  if (poll.loading) return <Loading />
  if (!poll.data) return <ErrorNotice error={poll.error!} onRetry={poll.reload} />

  const { data } = poll
  const live = data.status === 'open'

  return (
    <article className="host-poll">
      <div>
        <BackLink to="/anfitriao">Todas as votações</BackLink>
        <header className="host-poll__head">
          <StatusBadge status={data.status} />
          <h1 className="host-poll__question">{data.question}</h1>
          <p className="muted">Criada a {formatDate(data.created_at)}</p>
        </header>
      </div>

      <StatusControl poll={data} onChanged={poll.setData} />

      <section className="results-panel" aria-labelledby="results-heading">
        <div className="results-panel__head">
          <h2 id="results-heading" className="section-title section-title--flush">
            Resultados
          </h2>
          {live ? (
            <span className="live-note">
              <LiveDot /> Em direto, atualiza-se sozinho
            </span>
          ) : (
            <button type="button" className="button button--quiet" onClick={poll.reload}>
              Atualizar
            </button>
          )}
        </div>

        {poll.error && <ErrorNotice error={poll.error} onRetry={poll.reload} />}
        <ResultsBars results={data} large />
      </section>
    </article>
  )
}

// ── Mudar o estado ───────────────────────────────────────────────────────

interface StatusControlProps {
  poll: PollResults
  /** Recebe a votação atualizada devolvida pelo PATCH. */
  onChanged: (poll: PollResults) => void
}

function StatusControl({ poll, onChanged }: StatusControlProps) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<ApiError | null>(null)

  async function moveTo(status: PollStatus) {
    if (
      status === 'closed' &&
      !window.confirm('Fechar a votação? Deixa de aceitar votos e os resultados ficam visíveis para todos.')
    ) {
      return
    }
    setBusy(true)
    setError(null)
    try {
      onChanged(await changePollStatus(poll.id, status))
    } catch (err) {
      setError(err instanceof ApiError ? err : new ApiError(0, 'unknown_error', String(err)))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="control" aria-label="Estado da votação">
      {poll.status === 'draft' && (
        <>
          <p className="control__hint">O público ainda não vê esta votação. Ao abri-la, passa a aceitar votos.</p>
          <button type="button" className="button button--large" disabled={busy} onClick={() => moveTo('open')}>
            {busy ? 'A abrir…' : 'Abrir votação'}
          </button>
        </>
      )}

      {poll.status === 'open' && (
        <>
          <ShareLink url={publicPollUrl(poll.id)} />
          <button
            type="button"
            className="button button--large button--ink"
            disabled={busy}
            onClick={() => moveTo('closed')}
          >
            {busy ? 'A fechar…' : 'Fechar votação'}
          </button>
        </>
      )}

      {poll.status === 'closed' && (
        <p className="control__hint">Votação terminada. Os resultados são finais e o público já os pode ver.</p>
      )}

      {error && (
        <div className="control__error">
          <ErrorNotice error={error} />
        </div>
      )}
    </section>
  )
}
