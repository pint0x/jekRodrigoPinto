import { useState, type FormEvent } from 'react'
import { ApiError } from '../../api/client'
import { getPublicPoll, getPublicResults, vote } from '../../api/polls'
import type { PublicPollDetail } from '../../api/types'
import { BackLink } from '../../components/BackLink'
import { ErrorNotice, Loading, NotFound } from '../../components/Feedback'
import { ResultsBars } from '../../components/ResultsBars'
import { StatusBadge } from '../../components/StatusBadge'
import { useDocumentTitle, useIdParam } from '../../lib/routing'
import { useFetch } from '../../lib/useFetch'

/**
 * Enquanto a votação não está fechada, a página pergunta ao servidor de 3 em
 * 3 s como ela está. Assim, sem o participante recarregar (extra do Nível 3):
 * - quando o anfitrião fecha a votação, aparecem os resultados;
 * - quem abre o link antes de a votação abrir vê-a aparecer quando abrir.
 */
const REFRESH_MS = 3000

export function PollPage() {
  const pollId = useIdParam()

  const poll = useFetch(
    pollId === null ? null : `public-poll:${pollId}`,
    () => getPublicPoll(pollId!),
    (data) => (data?.status === 'closed' ? null : REFRESH_MS),
  )
  // Os resultados só são pedidos quando a votação está fechada (antes disso
  // o servidor recusaria com 403).
  const results = useFetch(
    poll.data?.status === 'closed' ? `public-results:${pollId}` : null,
    () => getPublicResults(pollId!),
  )

  // Aviso quando o voto é recusado porque a votação fechou entretanto.
  const [closedNotice, setClosedNotice] = useState<string | null>(null)

  useDocumentTitle(poll.data?.question)

  if (pollId === null || poll.error?.status === 404) {
    return (
      <NotFound
        message="Esta votação não existe ou ainda não está disponível."
        backTo="/"
        backLabel="Ver todas as votações"
      />
    )
  }
  if (poll.loading) return <Loading />
  if (!poll.data) return <ErrorNotice error={poll.error!} onRetry={poll.reload} />

  const { data } = poll

  return (
    <article>
      <BackLink to="/">Todas as votações</BackLink>
      <header className="poll-head">
        <StatusBadge status={data.status} />
        <h1 className="poll-question">{data.question}</h1>
      </header>

      {/* Erro numa atualização automática: os dados anteriores continuam visíveis. */}
      {poll.error && <ErrorNotice error={poll.error} onRetry={poll.reload} />}

      {data.status === 'open' && (
        <VoteSection
          poll={data}
          onServerChange={(message) => {
            setClosedNotice(message)
            poll.reload()
          }}
        />
      )}

      {data.status === 'closed' && closedNotice && (
        <p className="notice notice--info" role="status">
          {closedNotice} O teu voto não foi contado.
        </p>
      )}

      {data.status === 'closed' && (
        <section aria-labelledby="results-heading">
          <h2 id="results-heading" className="section-title">
            Resultados finais
          </h2>
          {results.loading && <Loading />}
          {results.error && <ErrorNotice error={results.error} onRetry={results.reload} />}
          {results.data && <ResultsBars results={results.data} />}
        </section>
      )}
    </article>
  )
}

// ── Votar ────────────────────────────────────────────────────────────────

interface VoteSectionProps {
  poll: PublicPollDetail
  /**
   * Chamado quando o estado no servidor mudou (votou-se, ou a votação fechou
   * entretanto), para a página voltar a pedir a votação. `message` explica
   * porque é que o voto foi recusado, se foi.
   */
  onServerChange: (message: string | null) => void
}

function VoteSection({ poll, onServerChange }: VoteSectionProps) {
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // Texto da opção escolhida nesta visita, para a confirmação.
  const [votedFor, setVotedFor] = useState<string | null>(null)

  if (poll.has_voted || votedFor !== null) {
    return (
      <div className="notice notice--success" role="status">
        <p className="notice__title">
          {votedFor !== null ? 'Obrigado, o teu voto foi registado!' : 'Já votaste nesta votação.'}
        </p>
        {votedFor !== null && <p>Votaste em «{votedFor}».</p>}
        <p className="notice__note">
          Os resultados aparecem aqui quando o anfitrião fechar a votação. Não precisas de recarregar a página.
        </p>
      </div>
    )
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    const option = poll.options.find((o) => o.id === selectedId)
    if (!option) {
      setError('Escolhe uma opção antes de votar.')
      return
    }

    setSubmitting(true)
    setError(null)
    try {
      await vote(poll.id, option.id)
      setVotedFor(option.text)
      onServerChange(null)
    } catch (err) {
      const apiError = err instanceof ApiError ? err : new ApiError(0, 'unknown_error', String(err))
      if (apiError.code === 'already_voted' || apiError.code === 'poll_not_open') {
        // O estado no servidor mudou (votaste noutro separador, ou a votação
        // fechou entretanto): voltar a pedir a votação mostra o estado certo.
        onServerChange(apiError.message)
      }
      setError(apiError.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <fieldset className="choices" disabled={submitting}>
        <legend className="choices__legend">Escolhe uma opção</legend>
        {poll.options.map((option) => (
          <label key={option.id} className="choice">
            <input
              type="radio"
              name="option"
              value={option.id}
              checked={selectedId === option.id}
              onChange={() => {
                setSelectedId(option.id)
                setError(null)
              }}
            />
            <span className="choice__mark" aria-hidden="true" />
            <span className="choice__text">{option.text}</span>
          </label>
        ))}
      </fieldset>

      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}

      <button type="submit" className="button button--large button--block vote-button" disabled={submitting}>
        {submitting ? 'A enviar…' : 'Votar'}
      </button>
    </form>
  )
}
