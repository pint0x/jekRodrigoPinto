import { Link } from 'react-router'
import { listPublicPolls } from '../../api/polls'
import type { PublicPollSummary } from '../../api/types'
import { ErrorNotice, Loading } from '../../components/Feedback'
import { LiveDot } from '../../components/StatusBadge'
import { useDocumentTitle } from '../../lib/routing'
import { useFetch } from '../../lib/useFetch'

/** Atualiza sozinha para mostrar votações acabadas de abrir ou fechar. */
const REFRESH_MS = 5000

export function PollListPage() {
  useDocumentTitle('Votações')
  const { data: polls, error, loading, reload } = useFetch('public-polls', listPublicPolls, REFRESH_MS)

  const open = polls?.filter((poll) => poll.status === 'open') ?? []
  const closed = polls?.filter((poll) => poll.status === 'closed') ?? []

  return (
    <>
      <h1 className="page-title">Votações</h1>

      {error && <ErrorNotice error={error} onRetry={reload} />}
      {loading && <Loading />}

      {polls && (
        <>
          <section aria-labelledby="open-heading">
            <h2 id="open-heading" className="section-title">
              A decorrer
            </h2>
            {open.length > 0 ? (
              <PollRows polls={open} />
            ) : (
              <p className="muted">Não há nenhuma votação aberta agora. Esta lista atualiza-se sozinha.</p>
            )}
          </section>

          {closed.length > 0 && (
            <section aria-labelledby="closed-heading">
              <h2 id="closed-heading" className="section-title">
                Terminadas
              </h2>
              <PollRows polls={closed} />
            </section>
          )}
        </>
      )}
    </>
  )
}

function PollRows({ polls }: { polls: PublicPollSummary[] }) {
  return (
    <ul className="poll-list">
      {polls.map((poll) => (
        <li key={poll.id}>
          <Link to={`/votacoes/${poll.id}`} className="poll-row">
            {poll.status === 'open' && <LiveDot />}
            <span className="poll-row__question">{poll.question}</span>
            <span className="poll-row__action">{poll.status === 'open' ? 'Votar' : 'Ver resultados'}</span>
          </Link>
        </li>
      ))}
    </ul>
  )
}
