import { Link, Outlet } from 'react-router'
import { Wordmark } from './Logo'

/**
 * As duas interfaces partilham a aplicação mas têm molduras diferentes:
 * o público vê uma coluna estreita, pensada para o telemóvel; o anfitrião
 * vê uma barra escura e uma área larga, pensada para o portátil ou projetor.
 */

export function PublicLayout() {
  return (
    <div className="public">
      <header className="public-header">
        <Wordmark to="/" />
      </header>
      <main className="public-main">
        <Outlet />
      </main>
      <footer className="public-footer">
        <Link to="/anfitriao">Painel do anfitrião</Link>
      </footer>
    </div>
  )
}

export function HostLayout() {
  return (
    <div className="host">
      <header className="host-header">
        <div className="host-header__inner">
          <Wordmark to="/anfitriao" />
          <span className="host-header__role">Painel do anfitrião</span>
          <Link to="/" className="host-header__link">
            Ver como público
          </Link>
        </div>
      </header>
      <main className="host-main">
        <Outlet />
      </main>
    </div>
  )
}
