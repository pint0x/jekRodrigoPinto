import { Link } from 'react-router'

/** Barras de resultados + ponto "em direto": o símbolo da aplicação. */
function LogoMark() {
  return (
    <svg className="logo-mark" viewBox="0 0 24 24" aria-hidden="true">
      <rect x="2" y="12" width="4.5" height="10" rx="2.25" fill="var(--violet-bar)" />
      <rect x="9.75" y="5" width="4.5" height="17" rx="2.25" fill="var(--violet-bar)" />
      <rect x="17.5" y="14" width="4.5" height="8" rx="2.25" fill="var(--violet-bar)" />
      <circle cx="19.75" cy="6.5" r="2.75" fill="var(--live)" />
    </svg>
  )
}

export function Wordmark({ to }: { to: string }) {
  return (
    <Link to={to} className="wordmark">
      <LogoMark />
      Live Pulse
    </Link>
  )
}
