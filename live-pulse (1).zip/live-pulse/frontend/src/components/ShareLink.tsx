import { useRef, useState } from 'react'

/** Link da votação para o público, com botão para copiar. */
export function ShareLink({ url }: { url: string }) {
  const [copied, setCopied] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  async function copy() {
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 2000)
    } catch {
      // A API de clipboard só existe em https/localhost. Sem ela, seleciona-se
      // o texto para o anfitrião copiar à mão.
      inputRef.current?.select()
    }
  }

  return (
    <div className="share">
      <label htmlFor="share-url" className="share__label">
        Link para o público
      </label>
      <div className="share__row">
        <input
          ref={inputRef}
          id="share-url"
          className="input share__input"
          value={url}
          readOnly
          onFocus={(event) => event.target.select()}
        />
        <button type="button" className="button button--secondary" onClick={copy}>
          {copied ? 'Copiado' : 'Copiar'}
        </button>
      </div>
    </div>
  )
}
