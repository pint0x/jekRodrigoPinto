import { Link } from 'react-router'
import type { ApiError } from '../api/client'

// Estados comuns a todas as páginas: a carregar, erro e "não encontrado".

export function Loading() {
  return (
    <p className="loading" role="status">
      A carregar…
    </p>
  )
}

export function ErrorNotice({ error, onRetry }: { error: ApiError; onRetry?: () => void }) {
  return (
    <div className="notice notice--error" role="alert">
      <p>{error.message}</p>
      {onRetry && (
        <button type="button" className="button button--quiet" onClick={onRetry}>
          Tentar outra vez
        </button>
      )}
    </div>
  )
}

interface NotFoundProps {
  message: string
  backTo: string
  backLabel: string
}

export function NotFound({ message, backTo, backLabel }: NotFoundProps) {
  return (
    <div className="empty">
      <p className="empty__title">{message}</p>
      <Link to={backTo} className="button button--secondary">
        {backLabel}
      </Link>
    </div>
  )
}
