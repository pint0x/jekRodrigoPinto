import type { PollStatus } from '../api/types'
import { STATUS_LABEL } from '../lib/format'

/** Ponto vermelho a pulsar: "isto está a acontecer agora". */
export function LiveDot() {
  return <span className="live-dot" aria-hidden="true" />
}

export function StatusBadge({ status }: { status: PollStatus }) {
  return (
    <span className={`badge badge--${status}`}>
      {status === 'open' && <LiveDot />}
      {STATUS_LABEL[status]}
    </span>
  )
}
