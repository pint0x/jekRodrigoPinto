import type { PollResults } from '../api/types'
import { formatPercent, formatVotes } from '../lib/format'

interface Props {
  results: PollResults
  /** Versão grande, para o painel do anfitrião (pensada para projetar). */
  large?: boolean
}

/**
 * Resultados em barras horizontais, sem bibliotecas de gráficos: cada barra é
 * um <div> com largura igual à percentagem.
 *
 * As opções mantêm a ordem original (não se ordenam por votos) para as barras
 * não trocarem de lugar enquanto os resultados se atualizam em direto.
 * A opção (ou opções, em caso de empate) com mais votos fica destacada.
 */
export function ResultsBars({ results, large = false }: Props) {
  const { options, total_votes } = results
  const maxVotes = Math.max(0, ...options.map((option) => option.votes))

  return (
    <div className={large ? 'results results--large' : 'results'}>
      <ul className="results__list">
        {options.map((option) => {
          const leading = total_votes > 0 && option.votes === maxVotes
          return (
            <li key={option.id} className={leading ? 'result result--leading' : 'result'}>
              <div className="result__head">
                <span className="result__text">{option.text}</span>
                <span className="result__percent">{formatPercent(option.percentage)}</span>
              </div>
              <div className="result__track" aria-hidden="true">
                <div className="result__bar" style={{ width: `${option.percentage}%` }} />
              </div>
              <span className="result__votes">{formatVotes(option.votes)}</span>
            </li>
          )
        })}
      </ul>
      <p className="results__total">
        Total: <strong>{formatVotes(total_votes)}</strong>
      </p>
    </div>
  )
}
