import { BrowserRouter, Route, Routes } from 'react-router'
import { NotFound } from './components/Feedback'
import { HostLayout, PublicLayout } from './components/Layouts'
import { HostPollListPage } from './pages/host/HostPollListPage'
import { HostPollPage } from './pages/host/HostPollPage'
import { NewPollPage } from './pages/host/NewPollPage'
import { PollListPage } from './pages/public/PollListPage'
import { PollPage } from './pages/public/PollPage'

/**
 * Mapa de páginas:
 *
 *   /                          público: lista de votações
 *   /votacoes/:id              público: votar / ver resultados
 *   /anfitriao                 anfitrião: lista de votações
 *   /anfitriao/nova            anfitrião: criar votação
 *   /anfitriao/votacoes/:id    anfitrião: estado e resultados
 */
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route index element={<PollListPage />} />
          <Route path="votacoes/:id" element={<PollPage />} />
          <Route
            path="*"
            element={<NotFound message="Esta página não existe." backTo="/" backLabel="Ver as votações" />}
          />
        </Route>

        <Route path="anfitriao" element={<HostLayout />}>
          <Route index element={<HostPollListPage />} />
          <Route path="nova" element={<NewPollPage />} />
          <Route path="votacoes/:id" element={<HostPollPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
