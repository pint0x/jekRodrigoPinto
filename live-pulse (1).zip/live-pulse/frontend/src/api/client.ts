import { getVoterToken } from '../lib/voterToken'

/**
 * Erro devolvido pela API (ou por falta de ligação).
 *
 * O backend responde sempre {code, detail, errors?}, por isso o resto da
 * aplicação só precisa de olhar para `code` (para decidir o que fazer) e
 * para `detail` (texto em português, pronto a mostrar).
 */
export class ApiError extends Error {
  readonly status: number
  readonly code: string
  /** Erros por campo, só nos erros de validação (400). */
  readonly fieldErrors: Record<string, unknown>

  constructor(status: number, code: string, detail: string, fieldErrors: Record<string, unknown> = {}) {
    super(detail)
    this.name = 'ApiError'
    this.status = status
    this.code = code
    this.fieldErrors = fieldErrors
  }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH'
  body?: unknown
}

/**
 * Único ponto do frontend que faz pedidos HTTP.
 * Trata do JSON, do identificador de votante e da conversão de erros.
 */
export async function request<T>(path: string, { method = 'GET', body }: RequestOptions = {}): Promise<T> {
  let response: Response
  try {
    response = await fetch(`/api${path}`, {
      method,
      headers: {
        Accept: 'application/json',
        'X-Voter-Token': getVoterToken(),
        ...(body !== undefined && { 'Content-Type': 'application/json' }),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })
  } catch {
    // fetch só rejeita quando não há resposta nenhuma (servidor em baixo, sem rede).
    throw new ApiError(0, 'network_error', 'Sem ligação ao servidor. Confirma que o backend está a correr.')
  }

  const data = await response.json().catch(() => null)

  if (!response.ok) {
    throw new ApiError(
      response.status,
      data?.code ?? 'unknown_error',
      data?.detail ?? `Erro inesperado do servidor (${response.status}).`,
      data?.errors ?? {},
    )
  }
  return data as T
}
