// Tipos das respostas da API. Espelham os serializers do Django,
// por isso se a API mudar, é aqui que o TypeScript nos avisa.

export type PollStatus = 'draft' | 'open' | 'closed'

export interface Option {
  id: number
  text: string
}

/** GET /api/polls/ */
export interface PublicPollSummary {
  id: number
  question: string
  status: PollStatus
  created_at: string
}

/** GET /api/polls/{id}/ */
export interface PublicPollDetail extends PublicPollSummary {
  options: Option[]
  has_voted: boolean
}

/** GET /api/host/polls/ */
export interface HostPollSummary extends PublicPollSummary {
  total_votes: number
}

export interface OptionResult extends Option {
  votes: number
  percentage: number
}

/** Resultados: /api/polls/{id}/results/ e todos os endpoints do anfitrião com {id} */
export interface PollResults extends PublicPollSummary {
  total_votes: number
  options: OptionResult[]
}

/** Corpo de POST /api/host/polls/ */
export interface NewPoll {
  question: string
  options: string[]
}

/** Resposta de POST /api/polls/{id}/votes/ */
export interface VoteReceipt {
  id: number
  option_id: number
}
