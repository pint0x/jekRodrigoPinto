// Uma função por endpoint. As páginas nunca constroem URLs à mão.

import { request } from './client'
import type {
  HostPollSummary,
  NewPoll,
  PollResults,
  PollStatus,
  PublicPollDetail,
  PublicPollSummary,
  VoteReceipt,
} from './types'

// ── Público ──────────────────────────────────────────────────────────────

export const listPublicPolls = () => request<PublicPollSummary[]>('/polls/')

export const getPublicPoll = (id: number) => request<PublicPollDetail>(`/polls/${id}/`)

export const vote = (pollId: number, optionId: number) =>
  request<VoteReceipt>(`/polls/${pollId}/votes/`, { method: 'POST', body: { option_id: optionId } })

export const getPublicResults = (id: number) => request<PollResults>(`/polls/${id}/results/`)

// ── Anfitrião ────────────────────────────────────────────────────────────

export const listHostPolls = () => request<HostPollSummary[]>('/host/polls/')

export const getHostPoll = (id: number) => request<PollResults>(`/host/polls/${id}/`)

export const createPoll = (poll: NewPoll) =>
  request<PollResults>('/host/polls/', { method: 'POST', body: poll })

export const changePollStatus = (id: number, status: PollStatus) =>
  request<PollResults>(`/host/polls/${id}/`, { method: 'PATCH', body: { status } })
