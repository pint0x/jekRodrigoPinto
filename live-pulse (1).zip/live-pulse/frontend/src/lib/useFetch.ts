import { useCallback, useEffect, useRef, useState } from 'react'
import { ApiError } from '../api/client'

interface FetchResult<T> {
  /** Últimos dados recebidos (mantêm-se durante as atualizações, sem "piscar"). */
  data: T | null
  /** Erro do último pedido. Se já havia dados, continuam disponíveis em `data`. */
  error: ApiError | null
  /** Só é true no primeiro carregamento, quando ainda não há dados nem erro. */
  loading: boolean
  /** Volta a pedir os dados já. */
  reload: () => void
  /** Substitui os dados localmente (ex.: com a resposta de um PATCH), sem novo pedido. */
  setData: (data: T) => void
}

/**
 * Intervalo de atualização em ms, ou null para não atualizar sozinho.
 * Pode depender dos dados atuais: (poll) => poll?.status === 'open' ? 2000 : null
 */
type Refresh<T> = number | null | ((data: T | null) => number | null)

/**
 * Vai buscar dados à API e, opcionalmente, volta a buscá-los de X em X ms.
 *
 * É assim que funciona o "tempo real" (Nível 3): polling. O componente diz
 * o que quer (`key` + `load`) e de quanto em quanto tempo (`refresh`).
 *
 * - `key` identifica o pedido. Quando muda (ex.: outra votação), os dados
 *   antigos deixam de ser mostrados e faz-se um pedido novo. `null` desliga.
 * - Com o separador escondido não se fazem pedidos; ao voltar, atualiza logo.
 * - Respostas que chegam depois de o componente mudar de pedido são ignoradas.
 */
export function useFetch<T>(key: string | null, load: () => Promise<T>, refresh: Refresh<T> = null): FetchResult<T> {
  // Guardamos a chave junto dos dados para nunca mostrar dados de outro pedido.
  const [state, setState] = useState<{ key: string | null; data: T | null; error: ApiError | null }>({
    key: null,
    data: null,
    error: null,
  })
  const [reloadCount, setReloadCount] = useState(0)

  const current = state.key === key
  const data = current ? state.data : null
  const error = current ? state.error : null
  const refreshMs = typeof refresh === 'function' ? refresh(data) : refresh

  // A função `load` muda a cada render; guardamo-la numa ref para não
  // reiniciar o efeito (e o intervalo) sempre que o componente renderiza.
  const loadRef = useRef(load)
  useEffect(() => {
    loadRef.current = load
  })

  useEffect(() => {
    if (key === null) return

    let active = true

    const run = () => {
      loadRef.current().then(
        (data) => active && setState({ key, data, error: null }),
        (error: unknown) =>
          active &&
          setState((prev) => ({
            key,
            data: prev.key === key ? prev.data : null,
            error: error instanceof ApiError ? error : new ApiError(0, 'unknown_error', String(error)),
          })),
      )
    }

    run()

    if (refreshMs === null) {
      return () => {
        active = false
      }
    }

    const interval = window.setInterval(() => {
      if (!document.hidden) run()
    }, refreshMs)
    const onVisible = () => {
      if (!document.hidden) run()
    }
    document.addEventListener('visibilitychange', onVisible)

    return () => {
      active = false
      window.clearInterval(interval)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [key, refreshMs, reloadCount])

  const reload = useCallback(() => setReloadCount((n) => n + 1), [])
  const setData = useCallback((data: T) => setState({ key, data, error: null }), [key])

  return { data, error, loading: key !== null && data === null && error === null, reload, setData }
}
