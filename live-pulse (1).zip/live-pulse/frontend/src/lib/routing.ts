import { useEffect } from 'react'
import { useParams } from 'react-router'

/** Lê o :id da rota como número. Devolve null se não for um id válido (ex.: /votacoes/abc). */
export function useIdParam(): number | null {
  const { id } = useParams()
  const value = Number(id)
  return Number.isInteger(value) && value > 0 ? value : null
}

/** Título do separador do browser: "Pergunta | Live Pulse". */
export function useDocumentTitle(title?: string | null) {
  useEffect(() => {
    document.title = title ? `${title} | Live Pulse` : 'Live Pulse'
  }, [title])
}
