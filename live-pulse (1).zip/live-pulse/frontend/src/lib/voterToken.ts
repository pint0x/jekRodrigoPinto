/**
 * Identificador anónimo deste browser, usado para "um voto por pessoa".
 *
 * É gerado na primeira visita e guardado em localStorage, por isso sobrevive
 * a recarregar a página. Não é uma identidade forte: limpar o localStorage,
 * abrir uma janela anónima ou mudar de browser gera um identificador novo
 * (ver README).
 */

const STORAGE_KEY = 'live-pulse:voter-token'

// Se o localStorage não estiver disponível (modo privado de alguns browsers),
// o identificador vive só em memória até a página ser recarregada.
let memoryToken: string | null = null

export function getVoterToken(): string {
  if (memoryToken) return memoryToken
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) return (memoryToken = stored)
  } catch {
    /* localStorage indisponível */
  }

  memoryToken = generateUuid()
  try {
    localStorage.setItem(STORAGE_KEY, memoryToken)
  } catch {
    /* fica só em memória */
  }
  return memoryToken
}

/**
 * UUID v4. crypto.randomUUID() só existe em contextos seguros (https ou
 * localhost); quando se abre a aplicação no telemóvel por http://192.168.x.x
 * não está disponível, por isso há uma alternativa com getRandomValues().
 */
function generateUuid(): string {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID()

  const bytes = crypto.getRandomValues(new Uint8Array(16))
  bytes[6] = (bytes[6] & 0x0f) | 0x40 // versão 4
  bytes[8] = (bytes[8] & 0x3f) | 0x80 // variante RFC 4122
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}
