import type { PollStatus } from '../api/types'

export const STATUS_LABEL: Record<PollStatus, string> = {
  draft: 'Rascunho',
  open: 'Aberta',
  closed: 'Fechada',
}

const percentFormat = new Intl.NumberFormat('pt-PT', { style: 'percent', maximumFractionDigits: 1 })
const integerFormat = new Intl.NumberFormat('pt-PT')
const dateFormat = new Intl.DateTimeFormat('pt-PT', {
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
})

/** 42.9 → "42,9 %" (o backend já envia a percentagem de 0 a 100). */
export const formatPercent = (value: number) => percentFormat.format(value / 100)

/** 1 → "1 voto", 1200 → "1200 votos" */
export const formatVotes = (count: number) => `${integerFormat.format(count)} ${count === 1 ? 'voto' : 'votos'}`

/** "2026-10-16T18:42:32+01:00" → "16/out., 18:42" */
export const formatDate = (iso: string) => dateFormat.format(new Date(iso))

/** Endereço que o público abre para votar. */
export const publicPollUrl = (id: number) => `${window.location.origin}/votacoes/${id}`
