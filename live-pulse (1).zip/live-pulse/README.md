# Live Pulse

Aplicação de votação em direto. O público vota no telemóvel ou no portátil; o anfitrião cria as votações, abre-as, fecha-as e vê os resultados.

```
live-pulse/
├── backend/    Django + SQLite
└── frontend/   React + TypeScript + Vite
```

## Como correr

Requer Python 3.10+ e Node.js 20.19+. São precisos dois terminais.

**Backend**

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

**Frontend**

```bash
cd frontend
npm install
npm run dev
```

Depois abre:

- **Público:** http://localhost:5173
- **Anfitrião:** http://localhost:5173/anfitriao

Para correr os testes do backend: `python manage.py test`.

## Níveis completados

- **Nível 1:** o público vê as votações abertas e fechadas e vota; o anfitrião cria votações (pergunta + 2 a 5 opções), muda o estado e vê os resultados.
- **Nível 2:** um voto por pessoa; o backend recusa votos em rascunhos e votações fechadas; validação com mensagens claras; resultados em percentagem com barras.
- **Nível 3:** o painel do anfitrião atualiza os resultados sozinho. Extra: a página do público passa para os resultados quando a votação fecha.

Extras: interface do público pensada para o telemóvel e testes automáticos no backend.

## API

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/polls/` | Votações abertas e fechadas (público) |
| GET | `/api/polls/{id}/` | Pergunta, opções e se este browser já votou |
| POST | `/api/polls/{id}/votes/` | Votar: `{"option_id": 3}` + header `X-Voter-Token` |
| GET | `/api/polls/{id}/results/` | Resultados, só se a votação estiver fechada |
| GET | `/api/host/polls/` | Todas as votações, com o total de votos (anfitrião) |
| POST | `/api/host/polls/` | Criar: `{"question": "...", "options": ["A", "B"]}` |
| GET | `/api/host/polls/{id}/` | Resultados, em qualquer estado |
| PATCH | `/api/host/polls/{id}/` | Mudar estado: `{"status": "open"}` ou `{"status": "closed"}` |

Os erros têm sempre o mesmo formato, por exemplo `{"code": "already_voted", "detail": "Já votaste nesta votação."}`. Códigos usados: 400 (dados inválidos), 403 (resultados antes de fechar), 404 (não existe, ou é um rascunho visto pelo público) e 409 (já votou, votação não aberta, mudança de estado inválida).

## Decisões

**Stack.** Django porque Python é a linguagem que domino melhor. Usei Django simples, sem Django REST Framework: são seis endpoints, e as views com `JsonResponse` mostram exatamente o que entra e o que sai. SQLite porque é o que o Django usa por omissão e não exige instalar nada. No frontend, React com TypeScript e Vite, CSS simples e React Router para as páginas.

**Modelo de dados.** Três tabelas: `Poll` (pergunta, estado, data), `Option` (pertence a uma votação) e `Vote` (opção escolhida, token do browser, data). As chaves estrangeiras usam `CASCADE`: apagar uma votação apaga as opções e os votos dela.

**Um voto por pessoa.** O browser gera um identificador aleatório na primeira visita, guarda-o em `localStorage` e envia-o em cada pedido. A tabela `Vote` tem uma restrição `UNIQUE(poll, voter_token)`, por isso é a própria base de dados que recusa um segundo voto. Para isso, `Vote` guarda também a votação, além da opção. É uma pequena redundância, mas garante a regra mesmo com dois pedidos ao mesmo tempo.

Isto pode ser contornado: limpando o `localStorage`, usando uma janela anónima ou outro browser, ou chamando a API diretamente com tokens inventados. Impedir isso exigiria contas de utilizador, que o enunciado diz para não fazer.

**Visibilidade.** As regras estão no backend, não só na interface: o público nunca recebe rascunhos, e os resultados só são enviados depois de a votação fechar.

**Tempo real (Nível 3).** Usei polling: o frontend volta a pedir os dados de 2 em 2 segundos (anfitrião) ou de 3 em 3 (público). Os dados só vão num sentido, do servidor para o browser, e o polling usa os endpoints que já existem, sem código novo no backend. WebSockets precisariam de Django Channels e de outro servidor. Server-Sent Events também seriam possíveis, mas, sem Redis, cada ligação teria de consultar a base de dados em ciclo no servidor. Para uma sala com dezenas de pessoas, o polling chega.

**Painel do anfitrião sem proteção.** Como o enunciado dispensa autenticação, qualquer pessoa que conheça `/anfitriao` pode usá-lo.

## O que melhoraria com mais tempo

- Proteger o painel do anfitrião (por exemplo, com uma palavra-passe).
- Limitar os votos por IP, para dificultar a fraude.
- Mostrar ao público em que opção votou, depois de a votação fechar.
- Um código QR com o link da votação.
