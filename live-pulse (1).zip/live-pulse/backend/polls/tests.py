from django.test import TestCase

from .models import Option, Poll, Vote


def make_poll(status="draft"):
    poll = Poll.objects.create(question="Pergunta?", status=status)
    Option.objects.create(poll=poll, text="A")
    Option.objects.create(poll=poll, text="B")
    return poll


class CreatePollTests(TestCase):
    def create(self, data):
        return self.client.post("/api/host/polls/", data, content_type="application/json")

    def test_creates_poll_in_draft(self):
        response = self.create({"question": "Melhor linguagem?", "options": ["Python", "Go"]})
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()["status"], "draft")
        self.assertEqual(Option.objects.count(), 2)

    def test_rejects_invalid_polls(self):
        invalid = [
            {"question": "   ", "options": ["A", "B"]},  # pergunta vazia
            {"question": "P?", "options": ["A"]},  # só 1 opção
            {"question": "P?", "options": ["A", "B", "C", "D", "E", "F"]},  # 6 opções
            {"question": "P?", "options": ["A", " "]},  # opção vazia
            {"question": "P?", "options": ["Python", "python"]},  # repetidas
        ]
        for data in invalid:
            response = self.create(data)
            self.assertEqual(response.status_code, 400, data)
            self.assertEqual(response.json()["code"], "validation_error")
        self.assertEqual(Poll.objects.count(), 0)


class PublicTests(TestCase):
    def test_drafts_are_hidden(self):
        draft = make_poll("draft")
        open_poll = make_poll("open")
        ids = [poll["id"] for poll in self.client.get("/api/polls/").json()]
        self.assertEqual(ids, [open_poll.id])
        self.assertEqual(self.client.get(f"/api/polls/{draft.id}/").status_code, 404)

    def test_results_only_after_closing(self):
        poll = make_poll("open")
        self.assertEqual(self.client.get(f"/api/polls/{poll.id}/results/").status_code, 403)
        poll.status = "closed"
        poll.save()
        self.assertEqual(self.client.get(f"/api/polls/{poll.id}/results/").status_code, 200)


class VoteTests(TestCase):
    def vote(self, poll, option, token="browser-1"):
        return self.client.post(
            f"/api/polls/{poll.id}/votes/",
            {"option_id": option.id},
            content_type="application/json",
            headers={"X-Voter-Token": token},
        )

    def test_vote_and_has_voted(self):
        poll = make_poll("open")
        self.assertEqual(self.vote(poll, poll.options.first()).status_code, 201)
        detail = self.client.get(f"/api/polls/{poll.id}/", headers={"X-Voter-Token": "browser-1"})
        self.assertTrue(detail.json()["has_voted"])

    def test_one_vote_per_browser(self):
        poll = make_poll("open")
        self.vote(poll, poll.options.first())
        response = self.vote(poll, poll.options.last())
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json()["code"], "already_voted")
        self.assertEqual(Vote.objects.count(), 1)

    def test_closed_poll_rejects_votes(self):
        poll = make_poll("closed")
        response = self.vote(poll, poll.options.first())
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json()["code"], "poll_not_open")

    def test_option_from_another_poll_is_rejected(self):
        poll = make_poll("open")
        other = make_poll("open")
        self.assertEqual(self.vote(poll, other.options.first()).status_code, 400)

    def test_percentages(self):
        poll = make_poll("open")
        a, b = poll.options.order_by("id")
        self.vote(poll, a, "browser-1")
        self.vote(poll, a, "browser-2")
        self.vote(poll, a, "browser-3")
        self.vote(poll, b, "browser-4")
        results = self.client.get(f"/api/host/polls/{poll.id}/").json()
        self.assertEqual(results["total_votes"], 4)
        self.assertEqual([o["percentage"] for o in results["options"]], [75.0, 25.0])


class StatusTests(TestCase):
    def change(self, poll, status):
        return self.client.patch(
            f"/api/host/polls/{poll.id}/", {"status": status}, content_type="application/json"
        )

    def test_draft_open_closed(self):
        poll = make_poll("draft")
        self.assertEqual(self.change(poll, "open").json()["status"], "open")
        self.assertEqual(self.change(poll, "closed").json()["status"], "closed")

    def test_invalid_transitions(self):
        self.assertEqual(self.change(make_poll("draft"), "closed").status_code, 409)
        self.assertEqual(self.change(make_poll("closed"), "open").status_code, 409)
        self.assertEqual(self.change(make_poll("open"), "draft").status_code, 409)
