import json

from django.db import IntegrityError, transaction
from django.db.models import Count
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from .models import Option, Poll, Vote

# Para onde cada estado pode avançar: Rascunho → Aberta → Fechada (nunca para trás).
NEXT_STATUS = {"draft": "open", "open": "closed"}


# ── Funções auxiliares ───────────────────────────────────────────────────


def error(status, code, detail, errors=None):
    """Todos os erros da API têm o mesmo formato: {"code": ..., "detail": ...}."""
    body = {"code": code, "detail": detail}
    if errors:
        body["errors"] = errors
    return JsonResponse(body, status=status)


def read_json(request):
    """Lê o corpo do pedido. Devolve None se não for um objeto JSON."""
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    return data


def get_public_poll(poll_id):
    """A votação com este id, se o público a puder ver (os rascunhos não contam)."""
    return Poll.objects.exclude(status="draft").filter(id=poll_id).first()


def poll_summary(poll):
    return {
        "id": poll.id,
        "question": poll.question,
        "status": poll.status,
        "created_at": poll.created_at,
    }


def poll_results(poll):
    """A votação com o número de votos e a percentagem de cada opção."""
    # Uma só query: SELECT ..., COUNT(vote.id) ... LEFT JOIN vote ... GROUP BY option.id
    options = list(poll.options.annotate(vote_count=Count("votes")).order_by("id"))
    total = sum(option.vote_count for option in options)

    results = poll_summary(poll)
    results["total_votes"] = total
    results["options"] = [
        {
            "id": option.id,
            "text": option.text,
            "votes": option.vote_count,
            "percentage": round(option.vote_count / total * 100, 1) if total > 0 else 0,
        }
        for option in options
    ]
    return results


def validate_poll(question, options):
    """Devolve os erros por campo. Um dicionário vazio quer dizer que está tudo bem."""
    errors = {}

    if not question:
        errors["question"] = ["A pergunta não pode estar vazia."]
    elif len(question) > 200:
        errors["question"] = ["A pergunta pode ter no máximo 200 caracteres."]

    if not isinstance(options, list) or not 2 <= len(options) <= 5:
        errors["options"] = ["Uma votação precisa de 2 a 5 opções."]
    elif "" in options:
        errors["options"] = ["As opções não podem estar vazias."]
    elif any(len(text) > 100 for text in options):
        errors["options"] = ["Cada opção pode ter no máximo 100 caracteres."]
    elif len({text.lower() for text in options}) != len(options):
        errors["options"] = ["Não podem existir opções repetidas."]

    return errors


# ── Público ──────────────────────────────────────────────────────────────


@require_GET
def public_polls(request):
    """GET /api/polls/ → votações abertas e fechadas."""
    polls = Poll.objects.exclude(status="draft").order_by("-created_at")
    # safe=False: o JsonResponse só aceita listas (e não só dicionários) com isto.
    return JsonResponse([poll_summary(poll) for poll in polls], safe=False)


@require_GET
def public_poll(request, poll_id):
    """GET /api/polls/{id}/ → pergunta, opções e se este browser já votou."""
    poll = get_public_poll(poll_id)
    if poll is None:
        return error(404, "not_found", "Votação não encontrada.")

    token = request.headers.get("X-Voter-Token", "")
    data = poll_summary(poll)
    data["options"] = [{"id": option.id, "text": option.text} for option in poll.options.order_by("id")]
    data["has_voted"] = poll.votes.filter(voter_token=token).exists()
    return JsonResponse(data)


@csrf_exempt
@require_POST
def vote(request, poll_id):
    """POST /api/polls/{id}/votes/ com {"option_id": 3} e o header X-Voter-Token."""
    poll = get_public_poll(poll_id)
    if poll is None:
        return error(404, "not_found", "Votação não encontrada.")
    if poll.status != "open":
        return error(409, "poll_not_open", "Esta votação não está aberta.")

    token = request.headers.get("X-Voter-Token", "").strip()
    if not token:
        return error(400, "missing_voter_token", "Falta o identificador de votante.")

    data = read_json(request) or {}
    option_id = data.get("option_id")
    option = None
    if isinstance(option_id, int):
        # Procurar só dentro das opções DESTA votação.
        option = poll.options.filter(id=option_id).first()
    if option is None:
        return error(400, "invalid_option", "Escolhe uma opção desta votação.")

    try:
        # O atomic() isola o INSERT: se a base de dados o recusar, só ele é desfeito.
        with transaction.atomic():
            new_vote = Vote.objects.create(poll=poll, option=option, voter_token=token)
    except IntegrityError:
        # A restrição UNIQUE(poll, voter_token) recusou: este browser já votou.
        return error(409, "already_voted", "Já votaste nesta votação.")

    return JsonResponse({"id": new_vote.id, "option_id": option.id}, status=201)


@require_GET
def public_results(request, poll_id):
    """GET /api/polls/{id}/results/ → só depois de a votação fechar."""
    poll = get_public_poll(poll_id)
    if poll is None:
        return error(404, "not_found", "Votação não encontrada.")
    if poll.status != "closed":
        return error(403, "results_not_available", "Os resultados só aparecem quando a votação fechar.")
    return JsonResponse(poll_results(poll))


# ── Anfitrião ────────────────────────────────────────────────────────────


@csrf_exempt
@require_http_methods(["GET", "POST"])
def host_polls(request):
    """GET /api/host/polls/ → todas as votações. POST → criar uma votação."""
    if request.method == "GET":
        polls = Poll.objects.annotate(total_votes=Count("votes")).order_by("-created_at")
        data = []
        for poll in polls:
            item = poll_summary(poll)
            item["total_votes"] = poll.total_votes
            data.append(item)
        return JsonResponse(data, safe=False)

    # POST: {"question": "...", "options": ["...", "..."]}
    data = read_json(request)
    if data is None:
        return error(400, "invalid_json", "O corpo do pedido tem de ser JSON.")

    question = str(data.get("question", "")).strip()
    options = data.get("options")
    if isinstance(options, list):
        options = [str(text).strip() for text in options]

    errors = validate_poll(question, options)
    if errors:
        return error(400, "validation_error", "Dados inválidos.", errors)

    # Ou fica gravada a votação com todas as opções, ou não fica nada.
    with transaction.atomic():
        poll = Poll.objects.create(question=question)
        for text in options:
            Option.objects.create(poll=poll, text=text)

    return JsonResponse(poll_results(poll), status=201)


@csrf_exempt
@require_http_methods(["GET", "PATCH"])
def host_poll(request, poll_id):
    """GET /api/host/polls/{id}/ → resultados. PATCH com {"status": "open"} → mudar o estado."""
    poll = Poll.objects.filter(id=poll_id).first()
    if poll is None:
        return error(404, "not_found", "Votação não encontrada.")

    if request.method == "PATCH":
        data = read_json(request) or {}
        new_status = data.get("status")
        if new_status != NEXT_STATUS.get(poll.status):
            return error(
                409,
                "invalid_transition",
                "Só se pode passar de Rascunho para Aberta e de Aberta para Fechada.",
            )
        poll.status = new_status
        poll.save()

    return JsonResponse(poll_results(poll))
