from django.urls import path

from . import views

urlpatterns = [
    # Público
    path("polls/", views.public_polls),
    path("polls/<int:poll_id>/", views.public_poll),
    path("polls/<int:poll_id>/votes/", views.vote),
    path("polls/<int:poll_id>/results/", views.public_results),
    # Anfitrião
    path("host/polls/", views.host_polls),
    path("host/polls/<int:poll_id>/", views.host_poll),
]
