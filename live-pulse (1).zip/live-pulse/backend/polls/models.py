from django.db import models

STATUS_CHOICES = [
    ("draft", "Rascunho"),
    ("open", "Aberta"),
    ("closed", "Fechada"),
]


class Poll(models.Model):
    question = models.CharField(max_length=200)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="draft")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.question


class Option(models.Model):
    # Se a votação for apagada, as opções dela também são (CASCADE).
    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name="options")
    text = models.CharField(max_length=100)

    def __str__(self):
        return self.text


class Vote(models.Model):
    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name="votes")
    option = models.ForeignKey(Option, on_delete=models.CASCADE, related_name="votes")
    # Identificador aleatório que o browser gera e guarda (localStorage).
    voter_token = models.CharField(max_length=64)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        # "Um voto por pessoa em cada votação": a base de dados recusa
        # um segundo voto com a mesma votação e o mesmo token.
        constraints = [
            models.UniqueConstraint(fields=["poll", "voter_token"], name="one_vote_per_poll")
        ]
